B05 - Dominovy portret: vstupni obrazky

mendel.png  Gregor Mendel, kolem 1862, neznamy autor. Public domain.
            https://commons.wikimedia.org/wiki/File:Gregor_Mendel_2.jpg
curie.png   Marie Curie, kolem 1920, foto Henri Manuel. Public domain.
            https://commons.wikimedia.org/wiki/File:Marie_Curie_c1920.jpg

Oba soubory: prevedeno do odstinu sedi (8 bitu), zmenseno na sirku 600 px.
Stazeno z Wikimedia Commons 3. 11. 2026.

ukaz_start.py  Pocatecni stav: Mendel jako mrizka odstinu 0-9 vedle 12 sad
               domina polozenych nahodne po radcich, vypise RMSE (funkce
               chyba) a ulozi start.png. Spusteni: python ukaz_start.py
               (potrebuje numpy, matplotlib, Pillow). Optimalizace v nem neni.
