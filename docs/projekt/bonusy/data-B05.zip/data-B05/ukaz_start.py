"""B05 – Dominový portrét: počáteční stav (žádná optimalizace).

Spuštění:  python ukaz_start.py   (odkudkoli, obrázek hledá vedle sebe)

Vezme S kompletních sad domina 0–9, položí kostky vodorovně po řádcích
v NÁHODNÉM pořadí a vykreslí je vedle cíle. Vypíše chybu (RMSE v tečkách).
Lepší rozmístění je vaše práce.
"""
from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image, ImageDraw

SLOZKA = Path(__file__).resolve().parent
S = 12                        # počet kompletních sad (55 kostek v každé)
R, C = 44, 30                 # mřížka R x C buněk, R * C = 110 * S
SADA = [(a, b) for a in range(10) for b in range(a, 10)]   # 55 kostek {a, b}

# --- cíl: obrázek -> mřížka odstínů t v [0, 9] (9 = nejsvětlejší) ---
obr = Image.open(SLOZKA / "mendel.png").convert("L").crop((40, 0, 560, 763))
t = 9 * np.asarray(obr.resize((C, R), Image.BOX), float) / 255

# --- řešení: každá kostka právě jednou, vodorovně po řádcích ---
rng = np.random.default_rng(0)
kostky = np.array(SADA * S)                   # 55 * S kostek, sloupce (a, b)
kostky = kostky[rng.permutation(len(kostky))]   # náhodné pořadí
otoc = rng.random(len(kostky)) < 0.5            # náhodné otočení o 180°
kostky[otoc] = kostky[otoc, ::-1]


def tecky(kostky):
    """Mřížka R x C počtů teček: kostky jdou po řádcích za sebou, a vlevo, b vpravo."""
    return kostky.reshape(R, C)


def chyba(kostky, t):
    """Účelová funkce: RMSE mezi tečkami a cílem přes všechny buňky."""
    return np.sqrt(np.mean((tecky(kostky) - t) ** 2))


print(f"{S} sad = {len(kostky)} kostek na mřížce {R} x {C}")
print(f"RMSE náhodného rozmístění: {chyba(kostky, t):.3f} teček")

# --- vykreslení kostek s tečkami (jen vizualizace) ---
B = 16                                        # velikost buňky v pixelech
POZ = {1: [4], 2: [2, 6], 3: [2, 4, 6], 4: [0, 2, 6, 8], 5: [0, 2, 4, 6, 8],
       6: [0, 2, 3, 5, 6, 8], 7: [0, 2, 3, 4, 5, 6, 8],
       8: [0, 1, 2, 3, 5, 6, 7, 8], 9: list(range(9))}   # pozice teček v mřížce 3x3
T = tecky(kostky)
img = Image.new("RGB", (C * B, R * B), (40, 36, 32))
d = ImageDraw.Draw(img)
for r in range(R):
    for c in range(0, C, 2):
        d.rounded_rectangle([c * B + 1, r * B + 1, (c + 2) * B - 2, (r + 1) * B - 2], 3, fill=(15, 15, 17))
        for k, n in enumerate(T[r, c:c + 2]):
            for p in POZ.get(int(n), []):
                x = (c + k) * B + B * (0.25 + 0.25 * (p % 3))
                y = r * B + B * (0.25 + 0.25 * (p // 3))
                d.ellipse([x - 1.6, y - 1.6, x + 1.6, y + 1.6], fill=(240, 235, 220))

fig, ax = plt.subplots(1, 2, figsize=(9, 6.6))
ax[0].imshow(t, cmap="gray", vmin=0, vmax=9)
ax[0].set_title("cíl: odstíny 0–9")
ax[1].imshow(img)
ax[1].set_title(f"náhodné rozmístění, RMSE {chyba(kostky, t):.2f}")
for a in ax:
    a.axis("off")
fig.tight_layout()
fig.savefig(SLOZKA / "start.png", dpi=110, bbox_inches="tight")
print("uloženo:", SLOZKA / "start.png")
if matplotlib.get_backend().lower() != "agg":   # okno jen tam, kde to jde
    plt.show()
