B01 – Evoluce plazícího tvorečka: data pro studenty
===================================================

tvorecek.py     simulátor (2D kuličky a tyčky, Verlet, tření o terén);
                simuluj(P, faze_terenu=0.0) -> vzdálenost v metrech
                pro každý řádek P tvaru (n, 23); se zaznam_kazdy=k vrátí
                i polohy kuliček pro animaci. Spuštěný samostatně
                nasimuluje 8 náhodných tvorečků a vypíše čas.
ukaz_start.py   počáteční stav: 8 náhodných tvorečků na hlavní trati,
                vypíše jejich vzdálenosti a uloží start.png (start
                a polohy po 10 s). Ukazuje, jak se simulátor volá;
                žádnou optimalizaci neobsahuje.

Parametry jednoho tvorečka (23 čísel): 11 amplitud svalů [0; 0.15],
11 fází [0; 2 pi), 1 společná frekvence [0.3; 3] Hz.
faze_terenu = 0 je hlavní trať, jiné hodnoty dávají jiné kopce.
