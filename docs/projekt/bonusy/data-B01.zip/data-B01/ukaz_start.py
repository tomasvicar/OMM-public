"""Počáteční stav úlohy B01: náhodní tvorečci na hlavní trati.

Skript neoptimalizuje – jen ukáže, jak se volá simulátor a kam dojdou
úplně náhodné svaly. Spuštění (z kořene repa i z této složky):

    python ukaz_start.py

Uloží obrázek start.png vedle sebe.
"""

import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

SLOZKA = Path(__file__).resolve().parent
sys.path.insert(0, str(SLOZKA))          # aby šel načíst tvorecek.py odkudkoli
from tvorecek import HRANY, UZLY, nahodne_parametry, simuluj, teren  # noqa: E402

# 1) Osm náhodných tvorečků. Každý řádek = 23 čísel:
#    11 amplitud, 11 fází, 1 frekvence (meze jsou v tvorecek.DOLNI/HORNI).
rng = np.random.default_rng(0)
P = nahodne_parametry(rng, 8)            # tvar (8, 23)

# 2) Účelová funkce = simulace. Vrátí posun těžiště po 10 s v metrech.
#    Se zaznam_kazdy=k vrátí i polohy kuliček každý k-tý krok (krok 0,01 s),
#    tady každý krok – poslední snímek je tedy konečná poloha.
vzdalenost, zaznam = simuluj(P, faze_terenu=0.0, zaznam_kazdy=1)
print("zaznam má tvar (snímky, tvorečci, kuličky, xy):", zaznam.shape)
for i, d in enumerate(vzdalenost):
    print(f"tvoreček {i}: {d:+.2f} m")
nej = int(np.argmax(vzdalenost))
print(f"nejlepší z náhodných: tvoreček {nej}, {vzdalenost[nej]:.2f} m")


def nakresli(ax, uzly, **styl):
    """Nakreslí jednoho tvorečka: tyčky jako úsečky, kuličky jako body."""
    for a, b in HRANY:
        ax.plot(*zip(uzly[a], uzly[b]), **styl)
    ax.plot(uzly[:, 0], uzly[:, 1], "o", ms=4, color=styl["color"],
            alpha=styl.get("alpha", 1))


fig, ax = plt.subplots(figsize=(12, 3.4))
xs = np.linspace(-4, 10, 800)
h, _ = teren(xs)                          # výška terénu (a sklon, ten tu nepotřebujeme)
ax.fill_between(xs, h, -0.8, color="#c9b99a")
ax.plot(xs, h, color="#7a6a4f")

for i in range(len(P)):                                       # konec po 10 s
    barva = "tab:orange" if i == nej else "tab:blue"
    nakresli(ax, zaznam[-1, i], color=barva, lw=2 if i == nej else 1,
             alpha=1 if i == nej else 0.4)
nakresli(ax, UZLY + [0, 0.02], color="black", lw=2)          # start: všichni stejně

ax.set_title("Start (černě) a poloha 8 náhodných tvorečků po 10 s; "
             f"nejlepší (oranžově) ušel {vzdalenost[nej]:.2f} m")
ax.set_xlabel("x [m]")
ax.set_ylabel("y [m]")
ax.set_aspect("equal")
ax.set_xlim(-4, 10)
ax.set_ylim(-0.8, 1.2)
fig.tight_layout()
fig.savefig(SLOZKA / "start.png", dpi=120, bbox_inches="tight")
print("uloženo:", SLOZKA / "start.png")

if plt.get_backend().lower() not in {"agg", "pdf", "svg", "ps", "cairo", "template"}:
    plt.show()
