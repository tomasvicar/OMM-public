"""Minimální 2D simulátor tvorečka z kuliček a tyček (dodává vyučující).

Fyzika je záměrně jednoduchá, aby se dala přečíst za půl hodiny:

* tělo = hmotné body (kuličky) spojené tyčkami; každá tyčka je zároveň
  "sval": její klidová délka periodicky kmitá
      L_e(t) = L0_e * (1 + a_e * sin(2*pi*f*t + phi_e)),
* pohyb = Verletova integrace s gravitací a mírným odporem vzduchu,
* tyčky = poziční omezení (position based dynamics, Jakobsen 2001),
  několik průchodů Gauss-Seidel za krok,
* terén = zvlněná křivka y = h(x); kulička pod terénem se vytlačí ven
  po normále a tření je Coulombovo: tečný posun se smí zmenšit nejvýš
  o mu * (hloubka vytlačení), tedy úměrně normálové síle.

Celá populace se simuluje najednou (vektorizace přes první osu), takže
generace 60 tvorečků trvá zhruba sekundu.

Použití:

    import numpy as np
    from tvorecek import simuluj, POCET_PARAMETRU, nahodne_parametry

    rng = np.random.default_rng(0)
    p = nahodne_parametry(rng, 60)      # (60, POCET_PARAMETRU)
    vzdalenost = simuluj(p)             # (60,) uražená vzdálenost v metrech

Spuštěním souboru (`uv run python tvorecek.py`) se nasimuluje 8 náhodných
tvorečků a vypíše, kam došli.
"""

from __future__ import annotations

import numpy as np

# ---------------------------------------------------------------------------
# Tělo: 7 kuliček, 11 tyček ("housenka z trojúhelníků"), rozměry v metrech
# ---------------------------------------------------------------------------
UZLY = np.array(
    [
        [0.00, 0.00], [0.50, 0.00], [1.00, 0.00], [1.50, 0.00],  # spodní řada
        [0.25, 0.45], [0.75, 0.45], [1.25, 0.45],                 # horní řada
    ]
)
HRANY = np.array(
    [
        [0, 1], [1, 2], [2, 3],          # spodní řada
        [4, 5], [5, 6],                  # horní řada
        [0, 4], [4, 1], [1, 5], [5, 2], [2, 6], [6, 3],  # diagonály
    ]
)
POCET_SVALU = len(HRANY)


def _obarvi_hrany(hrany):
    """Rozdělí hrany do skupin, ve kterých žádné dvě nesdílejí kuličku."""
    barvy: list[list[int]] = []
    for e, (u, w) in enumerate(hrany):
        for b in barvy:
            if all(u not in hrany[k] and w not in hrany[k] for k in b):
                b.append(e)
                break
        else:
            barvy.append([e])
    return [np.array(b) for b in barvy]


BARVY = _obarvi_hrany(HRANY.tolist())
# parametry: a_0..a_10 (amplitudy), phi_0..phi_10 (fáze), f (frekvence)
POCET_PARAMETRU = 2 * POCET_SVALU + 1
A_MAX = 0.15           # největší relativní změna délky svalu (±15 %)
F_MIN, F_MAX = 0.3, 3.0  # Hz
DOLNI = np.r_[np.zeros(POCET_SVALU), np.zeros(POCET_SVALU), F_MIN]
HORNI = np.r_[np.full(POCET_SVALU, A_MAX), np.full(POCET_SVALU, 2 * np.pi), F_MAX]

# ---------------------------------------------------------------------------
# Fyzikální konstanty
# ---------------------------------------------------------------------------
G = 9.81          # m/s^2
DT = 0.01         # s
T_SIM = 10.0      # s
NABEH = 1.0       # s, svaly se rozbíhají plynule (žádný počáteční kopanec)
ODPOR = 0.002     # útlum rychlosti za krok (odpor vzduchu)
MU = 0.8          # součinitel tření
ITERACE = 8       # průchodů omezení za krok
TUHOST = 0.15     # poddajnost tyček: kolik z chyby délky se srovná v jednom průchodu
                  # (měkké svaly = konečná síla; při 0.9 jsou svaly "nekonečně silné"
                  # a evoluce objeví skákání vysoko nad terén)


A1, A2 = 0.15, 0.04  # m, výšky dlouhých a krátkých vln (největší sklon asi 23°)


def teren(x: np.ndarray, faze: float = 0.0) -> tuple[np.ndarray, np.ndarray]:
    """Výška terénu h(x) a sklon h'(x). Terén mírně stoupá a klesá.

    `faze` posune vlny – stejný typ terénu, jiný konkrétní kopec.
    Na prvních 2 m je rovina (start), pak vlny nabíhají.
    """
    nabeh = np.clip((x - 2.0) / 3.0, 0.0, 1.0)
    dnabeh = np.where((x > 2.0) & (x < 5.0), 1.0 / 3.0, 0.0)
    w = A1 * np.sin(2 * np.pi * x / 4.0 + faze) + A2 * np.sin(2 * np.pi * x / 1.3 + 2.7 * faze)
    dw = A1 * 2 * np.pi / 4.0 * np.cos(2 * np.pi * x / 4.0 + faze) \
        + A2 * 2 * np.pi / 1.3 * np.cos(2 * np.pi * x / 1.3 + 2.7 * faze)
    w0 = A1 * np.sin(faze) + A2 * np.sin(2.7 * faze)  # aby start byl na h = 0
    h = nabeh * (w - w0)
    dh = nabeh * dw + dnabeh * (w - w0)
    return h, dh


def nahodne_parametry(rng: np.random.Generator, n: int) -> np.ndarray:
    """n rovnoměrně náhodných vektorů parametrů v povoleném rozsahu."""
    return DOLNI + (HORNI - DOLNI) * rng.random((n, POCET_PARAMETRU))


def simuluj(
    parametry: np.ndarray,
    faze_terenu: float = 0.0,
    t_sim: float = T_SIM,
    zaznam_kazdy: int = 0,
):
    """Nasimuluje populaci tvorečků.

    parametry : (P, 23) nebo (23,); hodnoty mimo rozsah se oříznou.
    faze_terenu : posun vln terénu (0 = hlavní trať).
    zaznam_kazdy : je-li > 0, vrátí i polohy kuliček každý n-tý krok.

    Vrací vzdálenost (P,) = posun těžiště ve směru x [m];
    s `zaznam_kazdy` navíc (vzdálenost, zaznam) se zaznam (K, P, 7, 2).
    Tvoreček, jehož simulace "vybuchne" (NaN, roztržené tělo), dostane -inf.
    """
    p = np.atleast_2d(np.asarray(parametry, dtype=float))
    p = np.clip(p, DOLNI, HORNI)
    P = p.shape[0]
    a = p[:, :POCET_SVALU]
    phi = p[:, POCET_SVALU : 2 * POCET_SVALU]
    f = p[:, -1:]

    i, j = HRANY[:, 0], HRANY[:, 1]
    L0 = np.linalg.norm(UZLY[j] - UZLY[i], axis=1)  # (E,)

    x = np.broadcast_to(UZLY + [0.0, 0.02], (P, len(UZLY), 2)).copy()
    x_pred = x.copy()
    start = x[:, :, 0].mean(axis=1)
    zaznam = []
    kroku = int(round(t_sim / DT))
    gdt2 = np.array([0.0, -G * DT * DT])

    for k in range(kroku):
        t = k * DT
        rozbeh = min(1.0, t / NABEH)
        L = L0 * (1.0 + rozbeh * a * np.sin(2 * np.pi * f * t + phi))  # (P, E)

        # Verlet
        v = (x - x_pred) * (1.0 - ODPOR)
        x_pred = x.copy()
        x = x + v + gdt2

        # tyčky (Gauss-Seidel, obě kuličky stejně těžké); hrany jedné barvy
        # nesdílejí kuličku, takže se dají opravit najednou
        for _ in range(ITERACE):
            for e in BARVY:
                d = x[:, j[e]] - x[:, i[e]]                      # (P, |e|, 2)
                delka = np.sqrt((d * d).sum(axis=-1)) + 1e-12
                oprava = (TUHOST * 0.5 * (delka - L[:, e]) / delka)[..., None] * d
                x[:, i[e]] += oprava
                x[:, j[e]] -= oprava

        # terén: vytlačení po normále + Coulombovo tření
        h, dh = teren(x[..., 0], faze_terenu)
        hloubka = h - x[..., 1]
        dotyk = hloubka > 0
        if dotyk.any():
            s = np.sqrt(1.0 + dh * dh)
            n = np.stack([-dh / s, 1.0 / s], axis=-1)   # normála
            tg = np.stack([1.0 / s, dh / s], axis=-1)   # tečna
            dn = np.where(dotyk, hloubka / s, 0.0)      # hloubka po normále
            x = x + n * dn[..., None]
            posun_t = ((x - x_pred) * tg).sum(axis=-1)  # tečný posun za krok
            brzda = np.minimum(np.abs(posun_t), MU * dn)
            x = x - tg * (np.sign(posun_t) * brzda)[..., None]

        if zaznam_kazdy and k % zaznam_kazdy == 0:
            zaznam.append(x.copy())

    vzdalenost = x[:, :, 0].mean(axis=1) - start
    # kontrola zdraví: NaN nebo tyčka natažená/stlačená o víc než 50 %
    d = x[:, j] - x[:, i]
    pomer = np.linalg.norm(d, axis=-1) / L0
    rozbity = ~np.isfinite(vzdalenost) | (np.abs(pomer - 1).max(axis=1) > 0.5 + A_MAX)
    vzdalenost = np.where(rozbity, -np.inf, vzdalenost)
    if zaznam_kazdy:
        return vzdalenost, np.array(zaznam)
    return vzdalenost


if __name__ == "__main__":
    import time

    rng = np.random.default_rng(0)
    p = nahodne_parametry(rng, 8)
    t0 = time.perf_counter()
    d = simuluj(p)
    print("vzdálenosti [m]:", np.round(d, 2))
    print(f"čas simulace 8 tvorečků: {time.perf_counter() - t0:.2f} s")
