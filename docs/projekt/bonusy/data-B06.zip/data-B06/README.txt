B06 – Turingovy skvrny: data pro studenty
==========================================

ukaz_start.py        začněte tady: nasimuluje vzor z výchozích parametrů,
                     vykreslí ho vedle cílů, vypíše vzdálenost podle
                     jednoduché míry (spektrum + histogram) a uloží
                     start.png
gray_scott.py        simulátor (černý box), funkce simuluj(F, k, s, seed)
                     -> pole v 96 x 96 po 4000 krocích; spusťte ho jednou
                     samostatně, vypíše čas jednoho vyhodnocení
cil_gepard.npy/.png  cílový vzor „gepard“ (pole v, float32, 96 x 96);
                     parametry jsou skryté
cil_zebra.npy/.png   cílový vzor „zebra“; parametry jsou skryté
trenink_zirafa.npy/.png
                     trénovací vzor se zveřejněnými parametry
                     F = 0.0390, k = 0.0580, s = 1.00 (seed 4444) –
                     na vyzkoušení, zda vaše fitness a optimalizace
                     najdou známou odpověď

Obrázky .png jsou jen náhled (zvětšený a obarvený); počítejte s .npy.
Povolené rozsahy: F v [0.010, 0.070], k v [0.045, 0.070], s v [0.5, 1.5].
Cíle vznikly stejným simulátorem, ale s jiným (neznámým) seedem než
použijete vy – skvrny tedy nikdy nebudou na stejných místech.
