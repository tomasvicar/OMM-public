"""B06 – Turingovy skvrny: ukázka počátečního stavu (žádná optimalizace).

Spuštění (z kořene repa i ze složky s daty):
    python ukaz_start.py

Načte cílové vzory, jednou zavolá simulátor s výchozími parametry, změří
jednoduchou mírou, jak moc se výsledek liší od cílů, a uloží start.png.
"""

from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import numpy as np

from gray_scott import simuluj  # simulátor leží ve stejné složce

SLOZKA = Path(__file__).resolve().parent
N = 96

# Radiální výkonové spektrum: kolik "energie" má vzor na které vlnové délce.
# Nezávisí na tom, kde přesně skvrny leží – jen na jejich velikosti a hustotě.
_f = np.fft.fftfreq(N)
POLOMER = np.rint(np.hypot(_f[:, None], _f[None, :]) * N).astype(int)


def statistiky(v):
    """Vrátí dvě kumulativní rozdělení: spektra (měřítko) a hodnot v (kontrast)."""
    spektrum = np.abs(np.fft.fft2(v - v.mean())) ** 2
    radialni = np.bincount(POLOMER.ravel(), spektrum.ravel())[1:33]
    hist = np.histogram(v, bins=40, range=(0.0, 0.5))[0]
    return np.cumsum(radialni) / max(radialni.sum(), 1e-12), np.cumsum(hist) / v.size


def vzdalenost(v1, v2):
    """Jednoduchá míra odlišnosti dvou vzorů (0 = statisticky stejné)."""
    s1, h1 = statistiky(v1)
    s2, h2 = statistiky(v2)
    return np.abs(s1 - s2).sum() / 2 + np.abs(h1 - h2).sum()


cile = {jm: np.load(SLOZKA / f"{jm}.npy")
        for jm in ("cil_gepard", "cil_zebra", "trenink_zirafa")}

# Jedno vyhodnocení černého boxu = jedna simulace (pár sekund).
start = dict(F=0.035, k=0.065, s=1.0)
v_start = simuluj(**start, seed=1)

# Pro představu o měřítku: žirafa se známými parametry, ale jiným seedem.
v_zirafa = simuluj(F=0.039, k=0.058, s=1.0, seed=7)

fig, osy = plt.subplots(1, 5, figsize=(15, 3.6))
for osa, (jm, v) in zip(osy, cile.items()):
    osa.imshow(v, cmap="copper")
    osa.set_title(f"{jm}\nvzdálenost od startu {vzdalenost(v_start, v):.2f}")
osy[3].imshow(v_start, cmap="copper")
osy[3].set_title("start: F={F}, k={k}, s={s}".format(**start))
osy[4].imshow(v_zirafa, cmap="copper")
osy[4].set_title("žirafa: správné F, k, s, jiný seed\n"
                 f"vzdálenost od cíle {vzdalenost(v_zirafa, cile['trenink_zirafa']):.2f}")
for osa in osy:
    osa.axis("off")
fig.tight_layout()
fig.savefig(SLOZKA / "start.png", dpi=110)
print("uloženo", SLOZKA / "start.png")
for jm, v in cile.items():
    print(f"{jm:16s} vzdálenost od startu {vzdalenost(v_start, v):.3f}")
if "agg" not in matplotlib.get_backend().lower():
    plt.show()
