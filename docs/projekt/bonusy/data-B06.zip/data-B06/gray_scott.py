"""Simulátor reakčně-difuzního modelu Gray–Scott (dodává vyučující).

Tímto souborem vznikly i cílové vzory, takže když ho použijete beze změny,
porovnáváte se přesně se stejným „černým boxem“.

Model na čtvercové mřížce N × N s periodickými okraji (torus):

    du/dt = s DU * lap(u) - u v^2 + F (1 - u)
    dv/dt = s DV * lap(v) + u v^2 - (F + k) v

DU = 0.16, DV = 0.08, s je „měřítko“ (násobí obě difuze, tedy zvětšuje
nebo zmenšuje vzor; povolený rozsah 0.5 až 1.5), explicitní Eulerův krok dt = 1, Laplacián je
pětibodový stencil (soused nahoře + dole + vlevo + vpravo - 4 * střed).
Start: u = 1, v = 0 a náhodně rozházené čtverečky 6 × 6 s u = 0.5,
v = 0.25 plus slabý šum; rozmístění určuje `seed`.

Výstupem je pole v (koncentrace „barviva“) po `kroky` krocích.

Použití:
    from gray_scott import simuluj
    v = simuluj(F=0.035, k=0.065, s=1.0, seed=1)   # numpy pole 96 × 96

Jedno vyhodnocení (96 × 96, 4000 kroků) trvá na notebooku zhruba 1–3 s.
"""

from __future__ import annotations

import numpy as np

DU, DV = 0.16, 0.08
N_VYCHOZI = 96
KROKY_VYCHOZI = 4000


def pocatecni_stav(n: int, seed: int) -> tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    u = np.ones((n, n), np.float32)
    v = np.zeros((n, n), np.float32)
    for _ in range(n * n // 400):
        x, y = rng.integers(0, n, 2)
        rx = (np.arange(x - 3, x + 3) % n)[:, None]
        ry = (np.arange(y - 3, y + 3) % n)[None, :]
        u[rx, ry] = 0.5
        v[rx, ry] = 0.25
    u += 0.05 * rng.random((n, n), dtype=np.float32)
    v += 0.05 * rng.random((n, n), dtype=np.float32)
    return u, v


def simuluj(F: float, k: float, s: float = 1.0, seed: int = 0,
            n: int = N_VYCHOZI,
            kroky: int = KROKY_VYCHOZI, snimky: int = 0):
    """Vrátí pole v po `kroky` krocích (tvar n × n, float32).

    Při `snimky` > 0 vrátí dvojici (v, seznam), kde seznam obsahuje kopii
    pole v po každých `snimky` krocích (hodí se na animaci růstu vzoru).
    """
    if not 0.5 <= s <= 1.5:
        raise ValueError("měřítko s musí ležet v intervalu [0.5, 1.5]")
    F = np.float32(F)
    k = np.float32(k)
    du = np.float32(DU * s)
    dv = np.float32(DV * s)
    u0, v0 = pocatecni_stav(n, seed)
    # Pole s okrajem šířky 1, do kterého se před každým krokem kopíruje
    # protější strana (periodické okraje bez np.roll, je to rychlejší).
    u = np.empty((n + 2, n + 2), np.float32)
    v = np.empty_like(u)
    u[1:-1, 1:-1] = u0
    v[1:-1, 1:-1] = v0
    uc, vc = u[1:-1, 1:-1], v[1:-1, 1:-1]
    lap = np.empty((n, n), np.float32)
    uvv = np.empty_like(lap)
    tmp = np.empty_like(lap)
    seznam = []
    for krok in range(kroky):
        for a in (u, v):
            a[0, 1:-1] = a[-2, 1:-1]
            a[-1, 1:-1] = a[1, 1:-1]
            a[:, 0] = a[:, -2]
            a[:, -1] = a[:, 1]
        np.multiply(uc, vc, out=uvv)
        uvv *= vc
        # du = s DU * lap(u) - u v^2 + F (1 - u)
        np.add(u[:-2, 1:-1], u[2:, 1:-1], out=lap)
        lap += u[1:-1, :-2]
        lap += u[1:-1, 2:]
        np.multiply(uc, 4, out=tmp)
        lap -= tmp
        lap *= du
        lap -= uvv
        np.subtract(1, uc, out=tmp)
        tmp *= F
        lap += tmp
        # dv = s DV * lap(v) + u v^2 - (F + k) v   (počítá se ze starého u, v)
        np.add(v[:-2, 1:-1], v[2:, 1:-1], out=tmp)
        tmp += v[1:-1, :-2]
        tmp += v[1:-1, 2:]
        uc += lap
        np.multiply(vc, 4, out=lap)
        tmp -= lap
        tmp *= dv
        tmp += uvv
        np.multiply(vc, F + k, out=lap)
        tmp -= lap
        vc += tmp
        if snimky and (krok + 1) % snimky == 0:
            seznam.append(vc.copy())
    return (vc.copy(), seznam) if snimky else vc.copy()


if __name__ == "__main__":
    import time

    t = time.perf_counter()
    pole = simuluj(0.035, 0.065, 1.0, seed=1)
    print(f"v: min {pole.min():.3f}, max {pole.max():.3f}, "
          f"čas {time.perf_counter() - t:.1f} s")
