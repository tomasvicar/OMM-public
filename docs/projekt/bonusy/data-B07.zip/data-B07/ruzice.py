"""Model listové růžice v květináči a světla, které za sezónu nachytá.

Použití (soubor ležící vedle vašeho skriptu):

    import ruzice
    x = [90.0, 0.8, 0.5, 0.2]          # (alfa, s, w, q)
    F = ruzice.cil(x)                   # účelová funkce, chceme ji MAXIMALIZOVAT
    d = ruzice.cil_detail(x)            # F, světlo, hmota, světlo v % květináče

Model (pohled shora, světlo dopadá svisle):
  * Květináč je kruh o poloměru R = 1. Za sezónu vyraší T = 30 listů,
    v každém kroku jeden. List číslo k míří do směru k * alfa,
    alfa je divergenční úhel ve stupních (stačí 0 až 180).
  * List starý a kroků má délku čepele L * (1 - exp(-a / tau)), před čepelí
    je řapík délky q * L a čepel je elipsa široká w * L. Mladší listy leží
    nahoře a stíní starším.
  * Světlo v kroku = plocha sjednocení všech listů (co je zakryté, se
    nepočítá dvakrát). Počítá se na polární mřížce 60 x 720 buněk.
  * Hmota (cena) v kroku = součet přes listy plocha * (1 + kappa * L)
    + c_p * délka řapíku.
  * Cíl F = průměrné světlo za sezónu - lam * průměrná hmota.
  * Celý list se musí vejít do květináče: (1 + q) * L <= R, proto se
    délka zadává poměrem s v [0,3; 1] a L = s * R / (1 + q).

Proměnné x = (alfa, s, w, q) a jejich meze jsou v LO a HI. Konstanty modelu
smíte měnit – je to váš model.
"""

import numpy as np

# ---------------------------------------------------------------- konstanty
R = 1.0          # poloměr květináče
T = 30           # počet kroků sezóny = počet listů
TAU = 5.0        # jak rychle listy dorůstají (větší = pomaleji)
KAPPA = 1.0      # větší list je dražší na jednotku plochy
CP = 0.3         # cena řapíku na jednotku délky
LAM = 0.15       # váha ceny v účelové funkci
ZLATY = 180.0 * (3.0 - np.sqrt(5.0))   # zlatý úhel 137,507...°
PLOCHA_KV = np.pi * R**2

#               alfa    s     w     q
LO = np.array([0.0,   0.3,  0.15, 0.0])
HI = np.array([180.0, 1.0,  0.9,  0.6])

# polární mřížka: NR prstenců × NT výsečí, A_PRSTENCE = plocha jedné buňky
NR, NT = 60, 720
POLOMERY = (np.arange(NR) + 0.5) / NR * R
UHLY = np.arange(NT) * 2 * np.pi / NT
A_PRSTENCE = POLOMERY * (R / NR) * (2 * np.pi / NT)


def rozbal(x):
    """x = (alfa, s, w, q) -> (alfa, L, w, q); hodnoty mimo meze se oříznou."""
    alfa, s, w, q = np.clip(np.asarray(x, dtype=float), LO, HI)
    return alfa, s * R / (1 + q), w, q


def delky_listu(t, L, tau=TAU):
    """Délky čepelí všech t listů v kroku t (list 0 je nejstarší)."""
    vek = t - np.arange(t)
    return L * (1 - np.exp(-vek / tau))


def polosirka(Lk, w, q):
    """Pro každý list a každý prstenec: o kolik radiánů na každou stranu
    od své osy list sahá. Hodnota -1 znamená, že list prstenec nezasahuje."""
    Lk = np.asarray(Lk, dtype=float)[:, None]
    zacatek, a = q * Lk, Lk / 2                     # začátek čepele, poloosa
    u = (POLOMERY[None, :] - zacatek - a) / np.maximum(a, 1e-9)   # -1..1 podél čepele
    pul_sirka = w * a * np.sqrt(np.clip(1 - u**2, 0, None))
    b = np.arcsin(np.clip(pul_sirka / POLOMERY[None, :], 0, 1))
    b[np.abs(u) > 1] = -1
    return b


def sezona(alfa, L, w, q, tau=TAU):
    """Simulace sezóny. Vrátí (světlo v každém kroku, hmota v každém kroku)."""
    smery = np.deg2rad(alfa) * np.arange(T)
    # úhlová vzdálenost každé výseče mřížky od osy každého listu
    d = np.abs((UHLY[None, :] - smery[:, None] + np.pi) % (2 * np.pi) - np.pi)
    svetlo, hmota = np.zeros(T), np.zeros(T)
    for t in range(1, T + 1):
        Lk = delky_listu(t, L, tau)
        b = polosirka(Lk, w, q)
        zakryto = (d[:t, None, :] <= b[:, :, None]).any(axis=0)   # sjednocení listů
        svetlo[t - 1] = (zakryto.sum(axis=1) * A_PRSTENCE).sum()
        plocha = np.pi * (Lk / 2) * (w * Lk / 2)
        hmota[t - 1] = (plocha * (1 + KAPPA * Lk) + CP * q * Lk).sum()
    return svetlo, hmota


def cil(x, lam=LAM):
    """Účelová funkce F(x) – čím větší, tím lepší rostlina."""
    alfa, L, w, q = rozbal(x)
    svetlo, hmota = sezona(alfa, L, w, q)
    return svetlo.mean() - lam * hmota.mean()


def cil_detail(x, lam=LAM):
    alfa, L, w, q = rozbal(x)
    svetlo, hmota = sezona(alfa, L, w, q)
    return dict(F=svetlo.mean() - lam * hmota.mean(), svetlo=svetlo.mean(),
                hmota=hmota.mean(), svetlo_pct=100 * svetlo.mean() / PLOCHA_KV)


# ---------------------------------------------------------------- kreslení
def obrys_listu(L, w, q, n=40):
    """Body obrysu čepele; list míří podél osy x."""
    s = np.linspace(0, 1, n)
    r = q * L + s * L                                # vzdálenost od středu
    hw = np.minimum(w * (L / 2) * np.sqrt(np.clip(1 - (2 * s - 1) ** 2, 0, None)), 0.999 * r)
    u = np.sqrt(np.maximum(r**2 - hw**2, 0))
    return np.vstack([np.c_[u, hw], np.c_[u, -hw][::-1]])


def kresli(ax, x, t=T, tau=TAU):
    """Nakreslí růžici v kroku t pohledem shora (nejstarší listy dospod)."""
    from matplotlib.patches import Circle, Polygon
    import matplotlib.cm as cm

    alfa, L, w, q = rozbal(x)
    ax.add_patch(Circle((0, 0), R, fc="#5b4636", ec="#3b2c20", lw=2))
    Lk = delky_listu(t, L, tau)
    for k in range(t):
        phi = np.deg2rad(alfa * k)
        rot = np.array([[np.cos(phi), np.sin(phi)], [-np.sin(phi), np.cos(phi)]])
        P = obrys_listu(Lk[k], w, q) @ rot
        barva = cm.YlGn(0.35 + 0.6 * (t - k) / T)    # starší = tmavší
        ax.plot([0, q * Lk[k] * np.cos(phi)], [0, q * Lk[k] * np.sin(phi)],
                color="#6b8e3a", lw=1, zorder=1 + k)          # řapík
        ax.add_patch(Polygon(P, fc=barva, ec="#1f4d22", lw=0.6, zorder=1 + k))
    ax.set_xlim(-1.08 * R, 1.08 * R)
    ax.set_ylim(-1.08 * R, 1.08 * R)
    ax.set_aspect("equal")
    ax.axis("off")
