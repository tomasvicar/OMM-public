B07 – Rostlina chytá světlo: podklady

ruzice.py      model listové růžice v květináči: simulace sezóny (sezona),
               účelová funkce cil(x) a cil_detail(x), meze LO a HI,
               kreslení růžice shora (kresli). Popis modelu je v hlavičce
               souboru. Konstanty i model smíte měnit nebo nahradit vlastním.
ukaz_start.py  ukázka, kde začít: výchozí rostlina s úhlem 90° shora,
               průběh světla a hmoty během sezóny, výpis F pro výchozí
               a jednu náhodnou rostlinu; uloží start.png. Nic neoptimalizuje.

Spuštění:  python ukaz_start.py   (potřebuje numpy a matplotlib)
Jedno vyhodnocení cil(x) trvá zhruba 0,1–0,15 s.
