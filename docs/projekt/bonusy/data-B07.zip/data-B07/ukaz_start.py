"""B07 – ukázka výchozí rostliny. Žádná optimalizace, jen start.

Spuštění (odkudkoli):  python ukaz_start.py
Nakreslí růžici s úhlem 90° pohledem shora, průběh světla během sezóny
a vypíše hodnotu účelové funkce. Obrázek uloží do start.png.
"""

import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

TU = Path(__file__).resolve().parent
sys.path.insert(0, str(TU))
import ruzice  # noqa: E402  (model leží ve stejné složce)

# Rostlina je popsaná čtyřmi čísly x = (alfa, s, w, q):
#   alfa  divergenční úhel ve stupních (0 až 180)
#   s     délka listu jako podíl poloměru květináče
#   w     šířka čepele vůči její délce
#   q     délka řapíku vůči délce čepele
x_start = np.array([90.0, 0.8, 0.5, 0.2])

# Takhle se volá účelová funkce – jedno číslo, čím větší, tím lepší:
F = ruzice.cil(x_start)
d = ruzice.cil_detail(x_start)  # totéž, ale i se světlem a hmotou zvlášť
print(f"výchozí rostlina x = {x_start.tolist()}")
print(f"  F = {F:.4f}   (průměrné světlo {d['svetlo']:.3f} - {ruzice.LAM} * hmota {d['hmota']:.3f})")
print(f"  rostlina nachytá {d['svetlo_pct']:.1f} % světla, které dopadá na květináč")

# Pro srovnání jedna náhodná rostlina z povolených mezí:
rng = np.random.default_rng(0)
x_nahodna = ruzice.LO + (ruzice.HI - ruzice.LO) * rng.random(4)
print(f"náhodná rostlina x = {np.round(x_nahodna, 3).tolist()}   F = {ruzice.cil(x_nahodna):.4f}")
print(f"meze proměnných: LO = {ruzice.LO.tolist()}, HI = {ruzice.HI.tolist()}")

# Průběh sezóny: světlo a hmota v každém kroku
alfa, L, w, q = ruzice.rozbal(x_start)
svetlo, hmota = ruzice.sezona(alfa, L, w, q)
kroky = np.arange(1, ruzice.T + 1)

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4.6),
                               gridspec_kw=dict(width_ratios=[1, 1.15]))
ruzice.kresli(ax1, x_start)
ax1.set_title(f"výchozí rostlina: úhel {alfa:.0f}°, konec sezóny", fontsize=11)

ax2.plot(kroky, 100 * svetlo / ruzice.PLOCHA_KV, "o-", color="#2e7d32", ms=3,
         label="zachycené světlo")
ax2.set_xlabel("krok sezóny (= počet listů)")
ax2.set_ylabel("světlo [% plochy květináče]")
ax2.set_ylim(0, 100)
ax2.grid(alpha=0.3)
ax2.set_title(f"F = {F:.3f}   (průměr světla {d['svetlo_pct']:.1f} %)", fontsize=11)
ax2b = ax2.twinx()
ax2b.plot(kroky, hmota, "--", color="#8d6e63", label="hmota listů")
ax2b.set_ylabel("hmota (cena)", color="#8d6e63")
fig.legend(loc="upper center", bbox_to_anchor=(0.72, 0.86), fontsize=9)
fig.tight_layout()

fig.savefig(TU / "start.png", dpi=110)
print(f"uloženo: {TU / 'start.png'}")
if "agg" not in plt.get_backend().lower():
    plt.show()
