B08 – Hejno proti predátorovi: data pro studenty
================================================

ukaz_start.py   začněte tady: ukáže, jak se volá simulátor (výchozí váhy
                na seedech 0–9 -> počet přeživších), nasimuluje jeden
                útok se záznamem, vykreslí tři okamžiky (start, první
                výpad predátora, konec) a uloží start.png
hejno.py        simulátor (neupravujte), funkce
                simuluj(vahy, seedy, zaznam=False) -> pole přeživších
                ryb (z 60) pro každý seed; zaznam=True vrátí navíc
                trajektorie ryb a predátora pro vlastní animaci.
                Spuštěný samostatně vypíše čas jednoho vyhodnocení.

Váhy: 6 čísel v pořadí NAZVY = soudržnost, zarovnání, odstup, útěk,
úhyb (vše 0–5) a dosah vnímání sousedů v metrech (0,5–10).
VYCHOZI = (1, 1, 1, 1, 0, 3), povolené rozsahy jsou v MEZE.
Stejný seed a stejné váhy dají vždy stejný výsledek; různé seedy jsou
různé útoky. Potřebujete jen numpy (a matplotlib pro obrázky).
