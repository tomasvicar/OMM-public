"""B08 – Hejno proti predátorovi: ukázka počátečního stavu.

Nasimuluje hejno s výchozími (učebnicovými) vahami na jednom seedu,
vykreslí tři okamžiky (start, první výpad predátora, konec po 90 s)
a vypíše, kolik ryb přežilo. Uloží obrázek start.png.

Spuštění:  python ukaz_start.py   (ze složky s daty i z kořene repozitáře)
"""

import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

SLOZKA = Path(__file__).resolve().parent
sys.path.insert(0, str(SLOZKA))
from hejno import ARENA, MEZE, N_RYB, NAZVY, VYCHOZI, simuluj  # noqa: E402

# --- 1) Jak se volá simulátor: vahy -> počet přeživších pro každý seed --------
print("Váhy (pořadí NAZVY) a povolené rozsahy MEZE:")
for jmeno, w, (lo, hi) in zip(NAZVY, VYCHOZI, MEZE):
    print(f"  {jmeno:11s} {w:4.1f}   [{lo}, {hi}]")

preziti = simuluj(VYCHOZI, seedy=range(10))  # 10 různých útoků najednou
print("\nVýchozí váhy, seedy 0–9: přežilo", preziti.tolist(), f"z {N_RYB}")
print(f"Průměrný podíl přeživších: {preziti.mean() / N_RYB:.3f}")
print("(Každý seed dopadne jinak – jedno číslo z jednoho seedu je hodně zašuměné.)")

# --- 2) Jeden seed se záznamem trajektorií, pro obrázek -----------------------
SEED = 7
Z = simuluj(VYCHOZI, seedy=[SEED], zaznam=True)
print(f"\nSeed {SEED}: přežilo {Z['preziti'][0]} z {N_RYB} ryb")

t_vypad = Z["vypady"][0][0] if Z["vypady"] else 10.0  # čas prvního výpadu
casy = [Z["cas"][0], t_vypad, Z["cas"][-1]]
titulky = ["start", "první výpad predátora", "konec"]

fig, osy = plt.subplots(1, 3, figsize=(13, 4.6))
for ax, t, titulek in zip(osy, casy, titulky):
    i = int(np.argmin(np.abs(Z["cas"] - t)))  # nejbližší uložený snímek
    ziva = Z["ziva"][i, 0]
    x, v = Z["ryby"][i, 0][ziva], Z["v_ryby"][i, 0][ziva]
    xp, vp = Z["predator"][i, 0], Z["v_predator"][i, 0]
    ax.quiver(x[:, 0], x[:, 1], v[:, 0], v[:, 1], color="tab:blue",
              angles="xy", scale_units="xy", scale=1.5, width=0.004)
    ax.quiver(*xp, *vp, color="tab:red", angles="xy", scale_units="xy",
              scale=1.0, width=0.01)
    ax.plot(*xp, "o", color="tab:red", ms=9, label="predátor")
    ax.set_title(f"{titulek}, t = {Z['cas'][i]:.1f} s\nživých ryb: {ziva.sum()}")
    ax.set_xlim(0, ARENA)
    ax.set_ylim(0, ARENA)
    ax.set_aspect("equal")
    ax.set_xticks([])
    ax.set_yticks([])
osy[0].legend(loc="lower left")
fig.suptitle(f"Výchozí váhy {VYCHOZI.tolist()}, seed {SEED}")
fig.tight_layout(rect=(0, 0, 1, 0.93))
fig.savefig(SLOZKA / "start.png", dpi=110)
print("Uloženo:", SLOZKA / "start.png")

if plt.get_backend().lower() not in ("agg", "pdf", "svg", "ps", "cairo", "template"):
    plt.show()
