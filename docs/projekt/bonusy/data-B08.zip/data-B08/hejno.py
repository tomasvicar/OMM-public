"""Simulátor hejna ryb, na které útočí predátor (bonus B08).

Dodává vyučující – fyziku neladíte, ladíte jen chování ryb (6 parametrů).

Použití:

    from hejno import simuluj, VYCHOZI, MEZE, NAZVY

    preziti = simuluj(VYCHOZI, seedy=range(10))      # pole: kolik ryb přežilo v každém seedu
    print(preziti.mean() / 60)                        # průměrný podíl přeživších

    zaznam = simuluj(VYCHOZI, seedy=[7], zaznam=True) # navíc trajektorie pro animaci

Parametry chování (vektor 6 čísel, pořadí podle NAZVY, rozsah MEZE):

    soudrznost  – tah ke středu sousedů,
    zarovnani   – přizpůsobení rychlosti a směru sousedům,
    odstup      – odpuzování od příliš blízkých sousedů,
    utek        – útěk přímo od predátora,
    uhyb        – úhyb do strany kolmo na směr predátorova útoku,
    dosah       – poloměr (m), ve kterém ryba vnímá sousedy.

Simulace je náhodná (počáteční poloha hejna i predátora, šum v pohybu ryb,
úspěšnost útoku). Stejný seed a stejné parametry dají vždy stejný výsledek.
Víc seedů se počítá najednou (vektorizovaně), takže 10 seedů trvá jen o málo
déle než jeden.
"""

from __future__ import annotations

import numpy as np

NAZVY = ("soudrznost", "zarovnani", "odstup", "utek", "uhyb", "dosah")
VYCHOZI = np.array([1.0, 1.0, 1.0, 1.0, 0.0, 3.0])
MEZE = np.array([[0.0, 5.0], [0.0, 5.0], [0.0, 5.0], [0.0, 5.0], [0.0, 5.0], [0.5, 10.0]])

# ---------------------------------------------------------------- pevná fyzika
N_RYB = 60
T = 90.0  # s
DT = 0.1  # s
ARENA = 32.0  # m, čtverec [0, ARENA]^2

V_RYBA_MIN, V_RYBA_MAX = 0.6, 2.2  # m/s
A_RYBA_MAX = 5.0  # m/s^2, ryba je obratná
SUM_RYBA = 0.6  # m/s^2, náhodné postrkování
R_ODSTUP = 1.2  # m, pod touto vzdáleností se ryby odpuzují (pravidlo odstupu)
R_TELO = 0.4  # m, těla se nepřekrývají (pevná fyzika, nezávisí na vahách)
R_PREDATOR = 7.0  # m, na tuto vzdálenost ryba vidí predátora

V_LOV = 3.5  # m/s, predátor je rychlejší než ryba ...
V_ODPOCINEK = 1.0  # m/s
OMEGA_PREDATOR = 1.4  # rad/s ... ale zatáčí pomalu
R_ZASAH = 0.45  # m, dosah výpadu
P_ZASAH = 0.9  # úspěšnost výpadu na osamělou rybu
R_ZMATENI = 1.5  # m, ryby v tomto okolí cíle predátora mátnou
K_ZMATENI = 0.05  # p = P_ZASAH / (1 + K_ZMATENI * pocet_sousedu_cile)
T_ODPOCINEK = 1.0  # s po každém výpadu (úspěšném i neúspěšném)
T_START = 4.0  # s, predátor zaútočí až po této době
T_HONBA = 4.0  # s, déle predátor jednu rybu nehoní, vzdá to a odpočine si

STENA = 4.0  # m, od stěny ryby i predátor uhýbají
A_STENA = 6.0


def _omez(v: np.ndarray, vmin: float, vmax: float) -> np.ndarray:
    rychlost = np.linalg.norm(v, axis=-1, keepdims=True)
    return v / np.maximum(rychlost, 1e-9) * np.clip(rychlost, vmin, vmax)


def _stena(x: np.ndarray) -> np.ndarray:
    """Měkké odpuzování od stěn arény."""
    bliz = np.clip((STENA - x) / STENA, 0, None) - np.clip((x - (ARENA - STENA)) / STENA, 0, None)
    return A_STENA * bliz * np.abs(bliz)


def simuluj(vahy, seedy=range(10), zaznam: bool = False, krok_zaznamu: int = 2):
    """Spustí simulaci pro každý seed a vrátí počet přeživších ryb (pole int).

    vahy        – 6 čísel v pořadí NAZVY (hodnoty mimo MEZE se ořežou),
    seedy       – seznam celých čísel, každý seed = jedna nezávislá simulace,
    zaznam      – True: vrátí slovník s trajektoriemi (pro animaci),
    krok_zaznamu – ukládá se každý k-tý krok (DT * k sekund mezi snímky).

    Záznam: 'ryby' (snímky, seedy, N_RYB, 2), 'v_ryby' (stejně), 'ziva'
    (snímky, seedy, N_RYB) bool, 'predator' a 'v_predator' (snímky, seedy, 2),
    'cas' (snímky,), 'preziti' (seedy,), 'vypady' (seznam (čas, seed, x, y, úspěch)).
    """
    w = np.clip(np.asarray(vahy, dtype=float), MEZE[:, 0], MEZE[:, 1])
    w_coh, w_ali, w_sep, w_esc, w_lat, r_sous = w
    seedy = list(seedy)
    S, N = len(seedy), N_RYB
    rng = [np.random.default_rng(s) for s in seedy]

    # počáteční stav: hejno v kruhu kolem středu, společný směr s rozptylem
    x = np.empty((S, N, 2))
    v = np.empty((S, N, 2))
    xp = np.empty((S, 2))
    vp = np.empty((S, 2))
    for i, g in enumerate(rng):
        stred = ARENA / 2 + g.uniform(-3, 3, 2)
        r = 3.0 * np.sqrt(g.uniform(0, 1, N))
        f = g.uniform(0, 2 * np.pi, N)
        x[i] = stred + np.c_[r * np.cos(f), r * np.sin(f)]
        smer = g.uniform(0, 2 * np.pi) + g.normal(0, 0.6, N)
        v[i] = 1.0 * np.c_[np.cos(smer), np.sin(smer)]
        uhel = g.uniform(0, 2 * np.pi)
        xp[i] = ARENA / 2 + 13 * np.array([np.cos(uhel), np.sin(uhel)])
        a = uhel + np.pi + g.normal(0, 0.3)
        vp[i] = V_ODPOCINEK * np.array([np.cos(a), np.sin(a)])
    ziva = np.ones((S, N), dtype=bool)
    odpocinek = np.full(S, T_START)
    zamek = np.full(S, -1)  # index ryby, kterou predátor právě honí (-1 = žádná)
    honba = np.zeros(S)
    # náhodná čísla pro šum a výpady předem, aby nezávisela na parametrech
    kroky = int(round(T / DT))
    sum_ryby = np.stack([g.normal(0, 1, (kroky, N, 2)) for g in rng], axis=1)
    hod = np.stack([g.uniform(0, 1, kroky) for g in rng], axis=1)

    if zaznam:
        Z = {k: [] for k in ("ryby", "v_ryby", "ziva", "predator", "v_predator", "cas")}
        vypady = []
    diag = 1e12 * np.eye(N)
    pryc = 1e5 * (1 + np.arange(N))[:, None] * np.ones(2)  # kam odklidit mrtvé

    for k in range(kroky):
        # ---------------------------------------------- ryby: pravidla hejna
        # mrtvé ryby jsou odklizené daleko (mimo), takže nikoho neovlivní
        dx = x[:, None, :, 0] - x[:, :, None, 0]  # dx[s, i, j] = x_j - x_i
        dy = x[:, None, :, 1] - x[:, :, None, 1]
        d2 = dx * dx + dy * dy + diag
        soused = (d2 < r_sous * r_sous).astype(float)
        n_s = soused.sum(-1, keepdims=True)
        ma = n_s > 0
        inv = 1.0 / np.maximum(n_s, 1)
        a_coh = (soused @ x * inv - x) * ma
        a_ali = (soused @ v * inv - v) * ma
        tlak = np.clip(R_ODSTUP**2 / d2 - 1.0, 0.0, 20.0)
        a_sep = -(tlak @ x - tlak.sum(-1, keepdims=True) * x)
        telo = np.clip(R_TELO**2 / d2 - 1.0, 0.0, 50.0)
        a_telo = -(telo @ x - telo.sum(-1, keepdims=True) * x) * 8.0

        # ---------------------------------------------- ryby: reakce na predátora
        od = x - xp[:, None, :]
        dp = np.linalg.norm(od, axis=-1, keepdims=True)
        vidi = (dp < R_PREDATOR) & ziva[..., None]
        sila = np.clip(1 - dp / R_PREDATOR, 0, 1) * vidi
        a_esc = od / np.maximum(dp, 1e-6) * sila * 4.0
        smer_p = vp / np.maximum(np.linalg.norm(vp, axis=-1, keepdims=True), 1e-9)
        kolmo = np.stack([-smer_p[:, 1], smer_p[:, 0]], -1)[:, None, :]
        strana = np.sign(np.sum(od * kolmo, -1, keepdims=True) + 1e-9)
        a_lat = kolmo * strana * sila * 4.0

        a = (w_coh * a_coh + w_ali * a_ali + w_sep * a_sep + w_esc * a_esc + w_lat * a_lat)
        a = _omez(a, 0.0, A_RYBA_MAX) + a_telo + SUM_RYBA * sum_ryby[k] + _stena(x)
        v = _omez(v + a * DT, V_RYBA_MIN, V_RYBA_MAX)
        x = np.where(ziva[..., None], x + v * DT, pryc)

        # ---------------------------------------------- predátor
        # predátor si vybere nejbližší rybu a honí ji, dokud nezaútočí nebo to nevzdá
        lovi = odpocinek <= 0
        idx = np.arange(S)
        dpr = np.where(ziva, np.linalg.norm(x - xp[:, None, :], axis=-1), np.inf)
        novy = lovi & ((zamek < 0) | ~ziva[idx, np.maximum(zamek, 0)])
        zamek = np.where(novy, np.argmin(dpr, axis=1), zamek)
        honba = np.where(novy, 0.0, honba)
        k_cili = x[idx, np.maximum(zamek, 0)] - xp
        chce = np.arctan2(k_cili[:, 1], k_cili[:, 0])
        stena_p = _stena(xp)
        ted = np.arctan2(vp[:, 1], vp[:, 0])
        # u stěny se predátor stáčí zpět do arény, jinak míří na nejbližší rybu
        u_steny = np.linalg.norm(stena_p, axis=-1) > 0.5
        chce = np.where(u_steny & ~lovi, np.arctan2(stena_p[:, 1], stena_p[:, 0]), chce)
        rozdil = (chce - ted + np.pi) % (2 * np.pi) - np.pi
        ted = ted + np.clip(rozdil, -OMEGA_PREDATOR * DT, OMEGA_PREDATOR * DT)
        rychl = np.where(lovi, V_LOV, V_ODPOCINEK)
        vp = rychl[:, None] * np.stack([np.cos(ted), np.sin(ted)], -1)
        xp = np.clip(xp + vp * DT, 0, ARENA)
        odpocinek -= DT
        honba += DT * lovi
        vzdal = lovi & (honba > T_HONBA)
        odpocinek[vzdal] = T_ODPOCINEK
        zamek[vzdal] = -1

        # výpad: nejbližší ryba v dosahu, úspěch snižuje zmatení
        dpr = np.where(ziva, np.linalg.norm(x - xp[:, None, :], axis=-1), np.inf)
        cil = np.argmin(dpr, axis=1)
        vypad = lovi & (dpr[idx, cil] < R_ZASAH)
        if vypad.any():
            dc = np.linalg.norm(x - x[idx, cil][:, None, :], axis=-1)
            n_zm = ((dc < R_ZMATENI) & ziva).sum(1) - 1
            p = P_ZASAH / (1 + K_ZMATENI * n_zm)
            uspech = vypad & (hod[k] < p)
            ziva[idx[uspech], cil[uspech]] = False
            odpocinek[vypad] = T_ODPOCINEK
            zamek[vypad] = -1
            if zaznam:
                for s in np.flatnonzero(vypad):
                    vypady.append(((k + 1) * DT, s, *xp[s], bool(uspech[s])))

        if zaznam and k % krok_zaznamu == 0:
            Z["ryby"].append(x.copy())
            Z["v_ryby"].append(v.copy())
            Z["ziva"].append(ziva.copy())
            Z["predator"].append(xp.copy())
            Z["v_predator"].append(vp.copy())
            Z["cas"].append((k + 1) * DT)

    preziti = ziva.sum(1)
    if not zaznam:
        return preziti
    Z = {k: np.array(h) for k, h in Z.items()}
    Z["preziti"] = preziti
    Z["vypady"] = vypady
    return Z


if __name__ == "__main__":
    import time

    t0 = time.perf_counter()
    p = simuluj(VYCHOZI, seedy=range(10))
    print(f"výchozí váhy: přežilo {p.tolist()} z {N_RYB}, průměr {p.mean() / N_RYB:.1%}, "
          f"{time.perf_counter() - t0:.1f} s")
