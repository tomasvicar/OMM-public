"""Počáteční stav úlohy B09: šest náhodných autíček na startu trati.

Skript neoptimalizuje – jen ukáže, jak se volá simulátor a kam dojedou
úplně náhodná auta. Spuštění (z kořene repa i z této složky):

    python ukaz_start.py

Potřebuje knihovnu pymunk. Uloží obrázek start.png vedle sebe.
"""

import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

SLOZKA = Path(__file__).resolve().parent
sys.path.insert(0, str(SLOZKA))            # aby šel načíst auticka.py odkudkoli
from auticka import MEZE, nahodny_genom, simuluj, teren, tvar  # noqa: E402

# 1) Šest náhodných aut. Genom = 14 čísel: 8 délek paprsků karoserie,
#    3 úhly, kde sedí kola, 3 poloměry kol (meze v MEZE).
rng = np.random.default_rng(0)
genomy = [nahodny_genom(rng) for _ in range(6)]
print("meze genomu (dolní, horní):\n", MEZE)

# 2) Účelová funkce = simulace jízdy na hlavní trati (seed=0).
#    Se zaznam=True vrátí i polohu karoserie a kol v každém kroku.
vysledky = [simuluj(g, seed=0, zaznam=True) for g in genomy]
for i, (d, z) in enumerate(vysledky):
    print(f"auto {i}: {d:6.1f} m  (konec: {z['konec']}, {z['t'][-1]:.1f} s)")


def nakresli_auto(ax, genom, x, y, uhel, barva):
    """Karoserie (mnohoúhelník z konců paprsků) a kola v poloze (x, y, uhel)."""
    obrys, osy, polomery = tvar(genom)
    R = np.array([[np.cos(uhel), -np.sin(uhel)], [np.sin(uhel), np.cos(uhel)]])
    obrys = obrys @ R.T + [x, y]
    osy = osy @ R.T + [x, y]
    ax.fill(obrys[:, 0], obrys[:, 1], color=barva, alpha=0.6, ec=barva, lw=1.5)
    for (cx, cy), r in zip(osy, polomery):
        ax.add_patch(plt.Circle((cx, cy), r, fc="#2b2b2b", ec="black", alpha=0.8))
        ax.plot(cx, cy, "o", color="white", ms=2)


T = teren(0)                                # lomená čára terénu, body (x, y)
fig = plt.figure(figsize=(12, 6.5))
barvy = plt.cm.tab10(np.arange(6))
for i, (g, (d, z)) in enumerate(zip(genomy, vysledky)):
    ax = fig.add_subplot(3, 3, i + 1)
    x, y, uhel = z["karoserie"][0]           # poloha na startu (první snímek)
    nakresli_auto(ax, g, x, y, uhel, barvy[i])
    ax.fill_between(T[:, 0], T[:, 1], -2, color="#8a7f6a")
    ax.set_title(f"auto {i}: ujelo {d:.1f} m")
    ax.set_xlim(x - 2.5, x + 2.5)
    ax.set_ylim(-0.5, 3.5)
    ax.set_aspect("equal")
    ax.axis("off")

ax = fig.add_subplot(3, 1, 3)               # celá trať a kde auta skončila
ax.fill_between(T[:, 0], T[:, 1], T[:, 1].min() - 3, color="#8a7f6a")
for i, (d, z) in enumerate(vysledky):
    ax.axvline(z["karoserie"][-1, 0], color=barvy[i], lw=2)
ax.set_title("Hlavní trať (prvních 200 m); svislé čáry = kde auta skončila")
ax.set_xlabel("x [m]")
ax.set_xlim(-6, 200)
fig.tight_layout()
fig.savefig(SLOZKA / "start.png", dpi=110)
print("uloženo:", SLOZKA / "start.png")

if plt.get_backend().lower() not in {"agg", "pdf", "svg", "ps", "cairo", "template"}:
    plt.show()
