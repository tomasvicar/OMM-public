"""B09 – Evoluce autíček: simulátor (2D fyzika v knihovně pymunk).

Autíčko = karoserie + 3 kola s motorem. Je popsané genomem se 14 čísly:

    index  0–7   délky 8 paprsků karoserie [m], paprsky míří pod úhly
                 0°, 45°, …, 315°; jejich konce tvoří obrys karoserie
    index  8–10  úhly, pod kterými sedí osy 3 kol na obvodu karoserie [rad]
    index 11–13  poloměry 3 kol [m]

Meze jsou v MEZE (tvar (14, 2): sloupec 0 = dolní, sloupec 1 = horní).
Hodnoty mimo meze simulátor ořízne, úhly kol bere modulo 2 pi.

Fyzika
------
- karoserie i kola jsou tuhá tělesa s pevnou hustotou (větší auto = těžší),
  kola jsou ke karoserii připojená čepem (otočný kloub) a poháněná motorem
  s pevnou cílovou úhlovou rychlostí a omezeným točivým momentem;
- části jednoho auta spolu nekolidují, s terénem ano (tření, mírný odraz);
- krok 1/60 s, gravitace 9,81 m/s².

Trať
----
Prvních 10 m je rovina, pak zvlněný terén, který se se vzdáleností
zhoršuje: strmější kopce, schody nahoru i dolů a díry (jámy, ze kterých
se nevyjede). Trať je dlouhá DELKA_TRATE m a určuje ji `seed`:
seed = 0 je hlavní trať, jiné seedy dávají jiné (neviděné) tratě stejného
typu. Pro daný genom a seed je simulace deterministická.

Konec jízdy a vzdálenost
------------------------
Jízda končí po LIMIT_CASU s, nebo když se auto zasekne (za ZASEKNUTI_S s
nepostoupí o 0,5 m dál), nebo když dojede na konec trati. Vzdálenost je
nejdál dosažená poloha těžiště karoserie ve směru x od startu, v metrech
(vždy >= 0). Pokud se simulace rozbije (rozjetý kloub, nesmyslná rychlost),
vrací se 0 – auto, které „podvádí“ fyziku, nic nedostane.

Použití
-------
    import numpy as np
    from auticka import nahodny_genom, simuluj
    g = nahodny_genom(np.random.default_rng(0))
    d = simuluj(g)                         # vzdálenost v metrech
    d, z = simuluj(g, zaznam=True)         # + záznam pohybu pro animaci

Spuštění samostatně (`python auticka.py`) změří čas 20 náhodných jízd.
Potřebuje knihovnu pymunk (`uv add pymunk`, nebo `pip install pymunk`).
"""

from __future__ import annotations

import math

import numpy as np
import pymunk

# ---------------------------------------------------------------------------
# Genom
# ---------------------------------------------------------------------------
POCET_PAPRSKU = 8
POCET_KOL = 3
DELKA_GENOMU = POCET_PAPRSKU + 2 * POCET_KOL          # 14
UHLY_PAPRSKU = np.arange(POCET_PAPRSKU) * 2 * np.pi / POCET_PAPRSKU

MEZE = np.array(
    [[0.2, 1.6]] * POCET_PAPRSKU          # délky paprsků [m]
    + [[0.0, 2 * np.pi]] * POCET_KOL      # úhly kol [rad]
    + [[0.15, 0.9]] * POCET_KOL           # poloměry kol [m]
)
NAZVY = ([f"paprsek_{k}" for k in range(POCET_PAPRSKU)]
         + [f"uhel_kola_{k}" for k in range(POCET_KOL)]
         + [f"polomer_kola_{k}" for k in range(POCET_KOL)])

# ---------------------------------------------------------------------------
# Fyzikální konstanty (neměňte, pokud nechcete jiný svět)
# ---------------------------------------------------------------------------
DT = 1 / 60
LIMIT_CASU = 45.0          # s
ZASEKNUTI_S = 3.0          # s bez postupu o 0,5 m -> konec
HUSTOTA_KAROSERIE = 3.0    # kg/m² (2D)
HUSTOTA_KOLA = 2.0         # kg/m²
TRENI_KOLA = 1.2
TRENI_KAROSERIE = 0.5
TRENI_TERENU = 1.0
ODRAZ = 0.1
OTACKY = 10.0              # cílová úhlová rychlost kol [rad/s]
MOMENT = 20.0              # maximální točivý moment jednoho motoru [N m]
DELKA_TRATE = 400.0        # m
NAROST = 90.0              # m, na jaké vzdálenosti dosáhne obtížnost maxima
MAX_SCHOD = 1.0            # m
MAX_DIRA = 2.6             # m
MAX_SKLON = 0.55           # rad
MAX_RYCHLOST = 40.0        # m/s – rychlejší těleso = rozbitá simulace
MAX_ROZJETI_KLOUBU = 0.2   # m – víc = rozbitý kloub


def nahodny_genom(rng: np.random.Generator) -> np.ndarray:
    """Rovnoměrně náhodný genom v mezích MEZE (tvar (14,))."""
    return rng.uniform(MEZE[:, 0], MEZE[:, 1])


def oriz(genom) -> np.ndarray:
    """Vrátí kopii genomu oříznutou do MEZE (úhly kol modulo 2 pi)."""
    g = np.asarray(genom, dtype=float).copy()
    if g.shape != (DELKA_GENOMU,):
        raise ValueError(f"genom musí mít tvar ({DELKA_GENOMU},), má {g.shape}")
    i = slice(POCET_PAPRSKU, POCET_PAPRSKU + POCET_KOL)
    g[i] = np.mod(g[i], 2 * np.pi)
    return np.clip(g, MEZE[:, 0], MEZE[:, 1])


def tvar(genom):
    """Geometrie auta v souřadnicích karoserie (těžiště paprsků v počátku).

    Vrátí (obrys, osy_kol, polomery_kol):
    obrys (8, 2) – konce paprsků, osy_kol (3, 2) – kde sedí osy kol,
    polomery_kol (3,).
    """
    g = oriz(genom)
    r = g[:POCET_PAPRSKU]
    obrys = np.c_[r * np.cos(UHLY_PAPRSKU), r * np.sin(UHLY_PAPRSKU)]
    osy = np.zeros((POCET_KOL, 2))
    krok = 2 * np.pi / POCET_PAPRSKU
    for k in range(POCET_KOL):
        u = g[POCET_PAPRSKU + k]
        j = int(u // krok) % POCET_PAPRSKU
        a, b = obrys[j], obrys[(j + 1) % POCET_PAPRSKU]
        # průsečík polopřímky pod úhlem u s hranou a–b obrysu
        d = np.array([math.cos(u), math.sin(u)])
        e = b - a
        det = d[0] * (-e[1]) - d[1] * (-e[0])
        t = (a[0] * (-e[1]) - a[1] * (-e[0])) / det
        osy[k] = t * d
    return obrys, osy, g[POCET_PAPRSKU + POCET_KOL:].copy()


# ---------------------------------------------------------------------------
# Trať
# ---------------------------------------------------------------------------
_TRATE: dict[int, np.ndarray] = {}


def teren(seed: int = 0) -> np.ndarray:
    """Lomená čára terénu jako pole bodů (n, 2) [m]. Start je v x = 0."""
    if seed in _TRATE:
        return _TRATE[seed]
    rng = np.random.default_rng([9, int(seed)])
    body = [(-6.0, 8.0), (-6.0, 0.0), (10.0, 0.0)]
    x, y, uhel = 10.0, 0.0, 0.0
    dalsi_prekazka = 25.0 + rng.uniform(0, 8)
    druh = rng.integers(3)
    while x < DELKA_TRATE:
        obtiz = min(1.0, (x - 10.0) / NAROST)             # 0 na startu, pak roste k 1
        if x >= dalsi_prekazka:
            druh = (druh + 1 + rng.integers(2)) % 3       # střídání druhů
            if druh == 0:                                  # schod nahoru
                y += 0.15 + MAX_SCHOD * obtiz * rng.uniform(0.6, 1.0)
                body.append((x, y))
            elif druh == 1:                                # schod dolů
                y -= 0.15 + MAX_SCHOD * obtiz * rng.uniform(0.6, 1.0)
                body.append((x, y))
            else:                                          # díra (jáma)
                sirka = 0.6 + MAX_DIRA * obtiz * rng.uniform(0.6, 1.0)
                body += [(x, y - 3.0), (x + sirka, y - 3.0)]
                x += sirka
                body.append((x, y))
            dalsi_prekazka = x + rng.uniform(12, 22) - 6 * obtiz
        max_uhel = 0.08 + MAX_SKLON * obtiz
        uhel = float(np.clip(0.55 * uhel + rng.normal(0, 0.6 * max_uhel) - 0.01 * y,
                             -max_uhel, max_uhel))        # -0.01 y: trať se drží u nuly
        x += 1.0
        y += math.tan(uhel)
        body.append((x, y))
    body.append((x, y + 8.0))                              # zeď na konci
    _TRATE[seed] = np.array(body)
    return _TRATE[seed]


# ---------------------------------------------------------------------------
# Simulace
# ---------------------------------------------------------------------------
def _postav(genom, seed):
    space = pymunk.Space()
    space.gravity = (0.0, -9.81)
    space.iterations = 30
    for a, b in zip(teren(seed)[:-1], teren(seed)[1:]):
        s = pymunk.Segment(space.static_body, tuple(a), tuple(b), 0.08)
        s.friction = TRENI_TERENU
        s.elasticity = ODRAZ
        space.add(s)

    obrys, osy, polomery = tvar(genom)
    # postavit auto tak, aby nejnižší bod byl 0,1 m nad rovinou startu
    spodek = min(obrys[:, 1].min(), (osy[:, 1] - polomery).min())
    pozice = (0.0, 0.1 - spodek)
    filtr = pymunk.ShapeFilter(group=1)

    karoserie = pymunk.Body()
    karoserie.position = pozice
    tvary = []
    for j in range(POCET_PAPRSKU):
        trojuhelnik = [(0.0, 0.0), tuple(obrys[j]), tuple(obrys[(j + 1) % POCET_PAPRSKU])]
        p = pymunk.Poly(karoserie, trojuhelnik)
        p.density = HUSTOTA_KAROSERIE
        p.friction = TRENI_KAROSERIE
        p.elasticity = ODRAZ
        p.filter = filtr
        tvary.append(p)
    space.add(karoserie, *tvary)

    kola, klouby = [], []
    for k in range(POCET_KOL):
        kolo = pymunk.Body()
        kolo.position = (pozice[0] + osy[k, 0], pozice[1] + osy[k, 1])
        c = pymunk.Circle(kolo, float(polomery[k]))
        c.density = HUSTOTA_KOLA
        c.friction = TRENI_KOLA
        c.elasticity = ODRAZ
        c.filter = filtr
        cep = pymunk.PivotJoint(karoserie, kolo, tuple(osy[k]), (0.0, 0.0))
        motor = pymunk.SimpleMotor(karoserie, kolo, OTACKY)    # kolo se točí doprava
        motor.max_force = MOMENT
        space.add(kolo, c, cep, motor)
        kola.append(kolo)
        klouby.append((tuple(osy[k]), kolo))
    return space, karoserie, kola, klouby, pozice[0]


def simuluj(genom, seed: int = 0, zaznam: bool = False):
    """Nasimuluje jízdu auta na trati `seed` a vrátí ujetou vzdálenost [m].

    Se `zaznam=True` vrátí dvojici (vzdalenost, z), kde z je slovník:
      z["t"] (n,) čas [s]; z["karoserie"] (n, 3) x, y, natočení [rad];
      z["kola"] (n, 3, 3) totéž pro každé kolo; z["konec"] důvod konce
      ("cas", "zaseknuti", "cil", "rozbite").
    """
    space, karoserie, kola, klouby, x0 = _postav(genom, seed)
    x_cil = teren(seed)[-1, 0] - 2.0
    kroku = int(round(LIMIT_CASU / DT))
    nejdal = 0.0
    znacka, cas_znacky = 0.0, 0.0
    konec = "cas"
    if zaznam:
        t_z, kar_z, kol_z = [], [], []

    def uloz(t):
        t_z.append(t)
        kar_z.append((karoserie.position.x, karoserie.position.y, karoserie.angle))
        kol_z.append([(k.position.x, k.position.y, k.angle) for k in kola])

    if zaznam:
        uloz(0.0)
    for i in range(1, kroku + 1):
        space.step(DT)
        t = i * DT
        x = karoserie.position.x - x0
        if zaznam:
            uloz(t)
        # kontrola, že se fyzika nerozbila
        rozbite = karoserie.velocity.length > MAX_RYCHLOST or not math.isfinite(x)
        for kotva, kolo in klouby:
            if (karoserie.local_to_world(kotva) - kolo.position).length > MAX_ROZJETI_KLOUBU:
                rozbite = True
        if rozbite:
            konec, nejdal = "rozbite", 0.0
            break
        nejdal = max(nejdal, x)
        if x > znacka + 0.5:
            znacka, cas_znacky = x, t
        elif t - cas_znacky > ZASEKNUTI_S:
            konec = "zaseknuti"
            break
        if karoserie.position.x > x_cil:
            konec = "cil"
            break
    if not zaznam:
        return float(nejdal)
    z = {"t": np.array(t_z), "karoserie": np.array(kar_z),
         "kola": np.array(kol_z), "konec": konec}
    return float(nejdal), z


if __name__ == "__main__":
    import time
    rng = np.random.default_rng(0)
    t0 = time.perf_counter()
    d = [simuluj(nahodny_genom(rng)) for _ in range(20)]
    t1 = time.perf_counter()
    print("vzdálenosti [m]:", np.round(d, 1))
    print(f"průměrný čas jedné simulace: {(t1 - t0) / 20 * 1000:.0f} ms")
