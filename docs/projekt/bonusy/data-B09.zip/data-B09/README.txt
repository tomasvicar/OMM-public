B09 – Evoluce autíček: data pro studenty
========================================

Potřebná knihovna: pymunk (2D fyzika). Instalace v projektu s uv:
    uv add pymunk
nebo jednorázově bez úpravy projektu:
    uv run --with pymunk python ukaz_start.py
(případně pip install pymunk).

auticka.py      simulátor (pymunk): karoserie z 8 paprsků + 3 kola s motorem
                na zvlněné trati, která se postupně zhoršuje (kopce,
                schody, díry).
                simuluj(genom, seed=0) -> ujetá vzdálenost v metrech;
                se zaznam=True vrátí i polohy karoserie a kol pro animaci.
                nahodny_genom(rng), meze MEZE (14 x 2), tvar(genom) pro
                kreslení, teren(seed) pro lomenou čáru trati.
                Spuštěný samostatně změří čas 20 náhodných jízd.
ukaz_start.py   počáteční stav: 6 náhodných aut na startu, vypíše jejich
                ujetou vzdálenost a uloží start.png (auta na startu a kde
                na trati skončila). Ukazuje, jak se simulátor volá;
                žádnou optimalizaci neobsahuje.

Genom (14 čísel): 8 délek paprsků karoserie [0.2; 1.6] m (úhly 0°, 45°,
…, 315°), 3 úhly, kde na obvodu karoserie sedí osy kol [0; 2 pi),
3 poloměry kol [0.15; 0.9] m.
seed = 0 je hlavní trať, jiné seedy dávají jiné tratě stejného typu.
Jedna jízda trvá na jednom jádře zhruba 10–100 ms.
