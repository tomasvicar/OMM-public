B04 - String art: cilove obrazky, parametry a startovni skript

Cilove obrazky jsou sedotonove 160 x 160 px, hodnota g (0-255) dava cilovou
tmavost d = 1 - g/255, mimo kruh je bila. Orezane, zmensene, kontrast natazeny.

cil-cajal.png      Hlavni motiv. Santiago Ramon y Cajal, fotografie 1899
                   (Clark University), restaurace Garrondo.
                   https://commons.wikimedia.org/wiki/File:Cajal-Restored.jpg
                   Public domain.

cil-hopper.png     Grace Hopper, fotografie U.S. Navy (James S. Davis, 1984).
                   https://commons.wikimedia.org/wiki/File:Commodore_Grace_M._Hopper,_USN_(covered).jpg
                   Public domain.

cil-neuron.png     Purkynovy bunky z mozecku holuba, kresba S. Ramon y Cajal, 1899.
                   https://commons.wikimedia.org/wiki/File:PurkinjeCell.jpg
                   Public domain. Zamerne tezky motiv (tenke cary).

parametry.json     Rozliseni platna, pocet hrebiku, minimalni rozestup hrebiku
                   u tetivy, kryti pixelu jednou niti (alfa), K_max niti
                   a sigma rozmazani pri hodnoceni.

ukaz_start.py      Pocatecni stav: hrebiky a vsechny tetivy, jednoducha
                   rasterizace tetivy (kryti_tetivy), model skladani niti
                   (render), ucelova funkce (chyba) a obrazek start.png
                   s cilem, 2000 nahodnymi nitmi a rozdilem.
                   Spusteni: python ukaz_start.py [cajal|hopper|neuron]
                   (numpy, matplotlib, Pillow). Trva par sekund.
                   Optimalizace v nem neni, ta je na vas.
