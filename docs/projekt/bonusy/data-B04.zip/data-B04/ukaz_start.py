"""B04 – String art: ukáže počáteční stav (cíl, hřebíky a náhodné nitě).

Spuštění:  python ukaz_start.py          (motiv cajal)
           python ukaz_start.py hopper   (nebo neuron)
Uloží start.png vedle tohoto skriptu. Žádná optimalizace tu není – ta je na vás.
"""
import json
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from PIL import Image

ADR = Path(__file__).resolve().parent
par = json.loads((ADR / "parametry.json").read_text())
N, P, ALFA = par["N_px"], par["pocet_hrebiku"], par["kryti_nite_alfa"]

# --- cíl: tmavost 0 (bílá) .. 1 (černá) ---------------------------------------
motiv = sys.argv[1] if len(sys.argv) > 1 else "cajal"
cil = 1 - np.asarray(Image.open(ADR / f"cil-{motiv}.png").convert("L"), float) / 255

# --- geometrie: hřebíky na kruhu a všechny povolené tětivy ---------------------
c, r = (N - 1) / 2, N / 2 - 1
uhly = 2 * np.pi * np.arange(P) / P
hrebiky = np.c_[c + r * np.cos(uhly), c + r * np.sin(uhly)]       # (x, y)
tetivy = [(a, b) for a in range(P) for b in range(a + 1, P)
          if min(b - a, P - (b - a)) >= par["min_rozestup_hrebiku"]]
yy, xx = np.mgrid[0:N, 0:N]
uvnitr = (xx - c) ** 2 + (yy - c) ** 2 <= r ** 2


def kryti_tetivy(a, b):
    """Podíl a_ij, kterým tětiva (a, b) zakryje každý pixel (jednoduchá rasterizace:
    body po 0.25 px, každý přičte svou délku do nejbližšího pixelu)."""
    p, q = hrebiky[a], hrebiky[b]
    n = int(np.hypot(*(q - p)) / 0.25) + 1
    t = np.linspace(0, 1, n)
    x = np.rint(p[0] + t * (q[0] - p[0])).astype(int).clip(0, N - 1)
    y = np.rint(p[1] + t * (q[1] - p[1])).astype(int).clip(0, N - 1)
    delka = np.zeros((N, N))
    np.add.at(delka, (y, x), np.hypot(*(q - p)) / n)
    return ALFA * np.minimum(delka, 1)


def render(vybrane):
    """Model: tmavost = 1 - prod_j (1 - a_ij) přes vybrané tětivy j."""
    svetlo = np.ones((N, N))
    for j in vybrane:
        svetlo *= 1 - kryti_tetivy(*tetivy[j])
    return 1 - svetlo


def rozmaz(obr, sigma=par["sigma_hodnoceni_px"]):
    """Gaussovo rozmazání (pohled z dálky), po řádcích a po sloupcích."""
    k = np.exp(-0.5 * (np.arange(-4, 5) / sigma) ** 2)
    k /= k.sum()
    obr = np.pad(obr, 4, mode="symmetric")
    obr = np.apply_along_axis(np.convolve, 0, obr, k, "same")
    obr = np.apply_along_axis(np.convolve, 1, obr, k, "same")
    return obr[4:-4, 4:-4]


def chyba(obr):
    """Účelová funkce: MAE rozmazaného renderu proti rozmazanému cíli uvnitř kruhu."""
    return float(np.abs(rozmaz(obr) - rozmaz(cil))[uvnitr].mean())


# --- počáteční stav: K náhodných tětiv -----------------------------------------
K = par["K_max_niti"]
rng = np.random.default_rng(0)
nahodne = rng.choice(len(tetivy), size=K, replace=False)
obraz = render(nahodne)
print(f"motiv {motiv}: {P} hřebíků, {len(tetivy)} tětiv, K = {K}")
print(f"chyba prázdného plátna:  {chyba(np.zeros((N, N))):.3f}")
print(f"chyba {K} náhodných nití: {chyba(obraz):.3f}")

fig, ax = plt.subplots(1, 3, figsize=(12, 4.3))
ax[0].imshow(cil, cmap="gray_r", vmin=0, vmax=1)
ax[0].plot(*hrebiky.T, ".", color="tab:red", ms=3)
ax[0].set_title(f"cíl ({motiv}) a {P} hřebíků")
ax[1].imshow(obraz, cmap="gray_r", vmin=0, vmax=1)
ax[1].set_title(f"{K} náhodných nití, chyba {chyba(obraz):.3f}")
ax[2].imshow(rozmaz(obraz) - rozmaz(cil), cmap="RdBu_r", vmin=-1, vmax=1)
ax[2].set_title("rozdíl po rozmazání (červená = moc tmavé)")
for a in ax:
    a.axis("off")
fig.tight_layout()
fig.savefig(ADR / "start.png", dpi=110)
if "agg" not in plt.get_backend().lower():
    plt.show()
