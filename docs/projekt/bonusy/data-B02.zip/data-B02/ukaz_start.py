"""B02 – počáteční stav: cíl, jednobarevné plátno a 100 náhodných trojúhelníků.

Spuštění (odkudkoli):  python ukaz_start.py
Uloží start.png vedle tohoto souboru. Žádná optimalizace tu není – ta je na vás.

Řešení = pole tvaru (N, 10), všechna čísla v [0, 1]; jeden řádek je jeden
trojúhelník: x1, y1, x2, y2, x3, y3 (zlomky šířky/výšky), r, g, b, alfa.
"""

from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image, ImageDraw

SLOZKA = Path(__file__).resolve().parent
SIRKA = 64  # chybu počítáme na malé zmenšenině (64 x 86 px), je to rychlé


def nacti_cil(soubor, sirka=SIRKA):
    im = Image.open(SLOZKA / soubor).convert("RGB")
    vyska = round(im.height * sirka / im.width)
    return np.asarray(im.resize((sirka, vyska), Image.LANCZOS), dtype=np.float32)


def vykresli(reseni, sirka, vyska, pozadi):
    """Nakreslí trojúhelníky postupně přes sebe na plátno barvy `pozadi`."""
    img = Image.new("RGB", (sirka, vyska), pozadi)
    kresli = ImageDraw.Draw(img, "RGBA")  # "RGBA" = kreslí s průhledností
    for t in reseni:
        vrcholy = [(t[0] * sirka, t[1] * vyska), (t[2] * sirka, t[3] * vyska),
                   (t[4] * sirka, t[5] * vyska)]
        barva = tuple(int(round(v * 255)) for v in t[6:10])
        kresli.polygon(vrcholy, fill=barva)
    return img


def chyba(reseni, cil, pozadi):
    """E_rel = MSE(obrázek) / MSE(jednobarevné plátno v průměrné barvě cíle)."""
    vyska, sirka = cil.shape[:2]
    obraz = np.asarray(vykresli(reseni, sirka, vyska, pozadi), dtype=np.float32)
    mse = ((obraz - cil) ** 2).mean()
    mse0 = ((cil - np.array(pozadi, dtype=np.float32)) ** 2).mean()
    return mse / mse0


cil = nacti_cil("darwin.png")
vyska, sirka = cil.shape[:2]
pozadi = tuple(int(round(v)) for v in cil.reshape(-1, 3).mean(axis=0))

rng = np.random.default_rng(0)
prazdne = np.zeros((0, 10))           # žádný trojúhelník = jen pozadí
nahodne = rng.random((100, 10))       # 100 náhodných trojúhelníků
E0 = chyba(prazdne, cil, pozadi)
E1 = chyba(nahodne, cil, pozadi)
print(f"cíl {sirka} x {vyska} px, barva pozadí {pozadi}")
print(f"E_rel jednobarevného plátna:    {E0:.3f}")
print(f"E_rel 100 náhodných trojúhelníků: {E1:.3f}")

# Chyba se počítá na 64 px, ale ukázat jde i větší obrázek (stejné řešení).
velky = 240
panely = [
    ("cíl (darwin.png)", Image.fromarray(cil.astype(np.uint8)).resize((velky, round(velky * vyska / sirka)))),
    (f"jednobarevné plátno\n$E_{{rel}}$ = {E0:.3f}", vykresli(prazdne, velky, round(velky * vyska / sirka), pozadi)),
    (f"100 náhodných trojúhelníků\n$E_{{rel}}$ = {E1:.3f}", vykresli(nahodne, velky, round(velky * vyska / sirka), pozadi)),
]
fig, osy = plt.subplots(1, 3, figsize=(9, 4.4))
for osa, (popis, obr) in zip(osy, panely):
    osa.imshow(obr)
    osa.set_title(popis, fontsize=10)
    osa.axis("off")
fig.tight_layout()
fig.savefig(SLOZKA / "start.png", dpi=110, bbox_inches="tight")
print(f"uloženo: {SLOZKA / 'start.png'}")
if "agg" not in matplotlib.get_backend().lower():
    plt.show()
