B02 - Obraz z pruhlednych trojuhelniku: vstupni obrazky a startovni skript

darwin.png         240 x 323 px, RGB. Hlavni cil.
                   Charles Darwin, fotografie Julia Margaret Cameron, 1868.
                   https://commons.wikimedia.org/wiki/File:Charles_Darwin_by_Julia_Margaret_Cameron_3.jpg
                   Public domain.

cajal-purkyne.png  240 x 281 px, RGB. Volitelny druhy cil.
                   Purkynovy bunky z mozecku holuba, kresba Santiago Ramon y Cajal, 1899.
                   https://commons.wikimedia.org/wiki/File:PurkinjeCell.jpg
                   Public domain.

ukaz_start.py      Pocatecni stav: vykresleni trojuhelniku (funkce vykresli),
                   vypocet chyby E_rel (funkce chyba) a obrazek start.png
                   s cilem, jednobarevnym platnem a 100 nahodnymi trojuhelniky.
                   Spusteni: python ukaz_start.py  (numpy, matplotlib, Pillow).
                   Optimalizace v nem neni, ta je na vas.

Oba obrazky jsou zmensene (Lanczos) nahledy originalu z Wikimedia Commons.
Chyba E_rel se v ukazce pocita na darwin.png zmensenem na sirku 64 px (64 x 86).
