Data k úloze M17 – Časovka do kopce i z kopce
============================================

Všechny tratě mají stejný formát (CSV, UTF-8, oddělovač čárka, desetinná
tečka). První řádek začíná znakem # a je to jen popis trati, druhý řádek je
hlavička, pak následuje jeden bod trati na řádek:

    vzdalenost_m  vzdálenost od startu podél trati [m], rostoucí, krok 100 m
                  (poslední krok může být kratší)
    lat, lon      zeměpisná šířka a délka [stupně]; u simulovaných tratí 0
    vyska_m       nadmořská výška bodu [m]

Jak z bodů udělat úseky (vyhlazení, délka úseků), zvolíte sami.

okruh_tisnov.csv
    Okruh Kuřim – Veverská Bítýška – Tišnov – Kuřim, 32,8 km, 330 bodů.
    Hlavní trať úlohy.

cervenohorske_sedlo.csv
    Kouty nad Desnou – Červenohorské sedlo – Bělá pod Pradědem, 18,0 km,
    182 bodů; stoupání 573 → 1011 m a stejně dlouhý sjezd.

simulovane/trat_seed101.csv … trat_seed104.csv
    Simulované zvlněné tratě o délce 30 km (4–9 náhodných kopců a údolí
    s výškou 15–120 m, mírný sklon celé trati a drobné vlnění).

sily-a-nadrz.svg, profily.svg
    Obrázky ze zadání.

Zdroj a licence
---------------
Geometrie skutečných tratí: © přispěvatelé OpenStreetMap, licence ODbL 1.0
(https://www.openstreetmap.org/copyright), trasa vypočtená směrovačem OSRM
(https://router.project-osrm.org). Při použití uveďte
„© OpenStreetMap contributors“.

Výška: SRTM 1″ (rozlišení asi 30 m), NASA/USGS, public domain, dotazováno
přes službu OpenTopoData (https://www.opentopodata.org). SRTM má v lese
a v údolích chybu několik metrů.

Staženo 3. 11. 2026. Simulované tratě vygeneroval vyučující, volně
k použití v projektu.

Parametry jezdce (hmotnost, odpory, CP, W′) jsou v zadání; jsou to běžné
hodnoty podle Martin J. C. et al. (1998), Validation of a mathematical model
for road cycling power, Journal of Applied Biomechanics 14:276–291, a modelu
kritického výkonu (Monod & Scherrer 1965; Skiba et al. 2012, Medicine &
Science in Sports & Exercise 44:1526–1532).
