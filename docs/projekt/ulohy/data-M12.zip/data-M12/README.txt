M12 – Smí pacient s náhradou lokte zvednout krabici 5 kg? Data pro studenty
==========================================================================

Data jsou SIMULOVANÁ (výukový model paže se dvěma klouby a osmi svaly).
Nejde o klinický nástroj; kilogramy z modelu nejsou lékařské doporučení.

Soubory (formát NumPy .npz, načtení: D = dict(np.load("natazena.npz")))
-----------------------------------------------------------------------
natazena.npz          hlavní instance: krabice od pasu na polici, paže se
                      na konci natáhne (pohyb 1,5 s, 50 snímků)
u_tela.npz            stejná paže, stejná výška police, ale pacient stojí
                      blíž – ruka skončí o 16 cm blíž u těla, loket zůstane
                      pokrčený
natazena_rychle.npz   jako natazena.npz, ale pohyb trvá 0,6 s
dalsi/osoba_NNN_natazena.npz, dalsi/osoba_NNN_u_tela.npz
                      tři další „pacienti“ (101–103): jiné délky segmentů,
                      síly svalů, ramena momentů, délka pohybu a mez J_max

Klíče v každém souboru (T = 50 snímků, M = 8 svalů)
---------------------------------------------------
R        (T, 2, M)  ramena momentů svalů [m]; řádek 0 = rameno, 1 = loket;
                    kladné = sval kloub ohýbá (flexe), záporné = natahuje
tau_arm  (T, 2)     moment, který musí svaly dodat bez krabice [N m]
tau_box  (T, 2)     přírůstek tohoto momentu na 1 kg krabice [N m/kg]
C        (T, 2, M)  jednotkové směry tahu svalů na předloktí v souřadnicích
                    (x dopředu, y nahoru) [-]; sloupce 0 a 1 jsou nulové
d_arm    (T, 2)     síla, kterou musí sval + kloub dodat předloktí bez
                    krabice [N] (setrvačnost a tíha předloktí)
d_box    (T, 2)     přírůstek této síly na 1 kg krabice [N/kg]
Fmax     (M,)       maximální síla každého svalu [N]
m_box    ()         hmotnost krabice ze zadání [kg] (5)
J_max    ()         předpokládaná mez kontaktní síly implantátu [N]
q        (T, 2)     úhly [°]: q[:,0] flexe ramene (0 = paže svisle dolů),
                    q[:,1] flexe lokte (0 = natažený loket)
t        (T,)       čas snímku [s]
ruka     (T, 2)     poloha ruky vůči rameni (x dopředu, y nahoru) [m]
dur      ()         délka pohybu [s]
svaly    (M,)       zkratky svalů (pořadí sloupců):
                    0 DELTa    deltový sval, přední část (jen rameno)
                    1 PECMc    velký prsní sval, klíční část (jen rameno)
                    2 BIClong  dvojhlavý sval, dlouhá hlava (rameno + loket)
                    3 BICshort dvojhlavý sval, krátká hlava (rameno + loket)
                    4 BRA      hluboký sval pažní, brachialis (jen loket)
                    5 BRD      sval vřetenní, brachioradialis (jen loket)
                    6 TRIlong  trojhlavý sval, dlouhá hlava (rameno + loket)
                    7 TRIlat   trojhlavý sval, boční hlava (jen loket)
trajektorie ()      "natazena" nebo "u_tela"

Rovnice (podrobně v zadání)
---------------------------
rovnováha momentů:  R[t] @ F[t] = tau_arm[t] + m * tau_box[t]
kontaktní síla:     J[t] = d_arm[t] + m * d_box[t] - C[t] @ F[t]
mez implantátu:     ||J[t]||_2 <= J_max

Zdroj a licence
---------------
Simulace připravená vyučujícím (vlastní inverzní dynamika dvoučlánkové
paže, trajektorie s minimálním trhnutím). Maximální síly svalů podle
Holzbaur K. R. S., Murray W. M., Delp S. L. (2005), A model of the upper
extremity for simulating musculoskeletal surgery and analyzing
neuromuscular control, Ann Biomed Eng 33:829–840 (stejné hodnoty používá
výukový model OpenSim arm26). Tvar ramen momentů v lokti podle Murray
W. M., Delp S. L., Buchanan T. S. (1995), J Biomech 28:513–525. Převzata
jen čísla z článků, žádné soubory modelů. Mez J_max je předpoklad úlohy,
ne parametr skutečného implantátu.
Licence: volně k použití v projektu.
