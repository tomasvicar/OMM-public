S13 – syntetické bílé krvinky a klasifikátor

model.npz    náhodný les (100 stromů) jako pole: priznak, prah, vlevo, vpravo,
             hodnota (podíly tříd v uzlu), hloubka, tridy. Čte ho simulator.py.
obrazky.npz  obrazky (20, 28, 28, 3) float32 v [0, 1], tridy (20,) int 0..4
             (4 na třídu, seřazené podle třídy),
             nazvy = neutrofil, eozinofil, bazofil, lymfocyt, monocyt.
Obrázky i model jsou syntetické, licence se neřeší.
