M10 – Férový screening: data pro studenty
=========================================

Soubory
-------
screening_seed0.csv        hlavní data: 5000 simulovaných pacientů (1000 trénovacích, 4000 testovacích)
processed.cleveland.data   skutečná data UCI Heart Disease, Cleveland (303 pacientů) – pro vlastní experiment
svm-okraj.svg              obrázek ze zadání (schéma lineárního SVM s měkkým okrajem)

screening_seed0.csv
-------------------
Text CSV, oddělovač čárka, desetinná tečka, první řádek je hlavička,
hodnoty markerů zaokrouhlené na 3 desetinná místa. Jeden řádek = jeden pacient.

sloupec    jednotka    význam
glukoza    mmol/l      glukóza v krvi nalačno
hba1c      mmol/mol    glykovaný hemoglobin HbA1c
bmi        kg/m2       body mass index
tg         mmol/l      triglyceridy v krvi
alt        ukat/l      alaninaminotransferáza (jaterní enzym)
oblast_B   0/1         1 = pacient bydlí v oblasti B, 0 = v oblasti A
nemoc      -1/+1       +1 = má (nediagnostikovaný) diabetes 2. typu nebo prediabetes, -1 = nemá
test       0/1         0 = trénovací řádek, 1 = testovací řádek

V obou oblastech i v obou částech je nemocných přesně 30 %. Oblast B tvoří
40 % pacientů.

processed.cleveland.data
------------------------
Text bez hlavičky, oddělovač čárka, 14 sloupců, chybějící hodnota je "?"
(6 řádků s "?" vynechte, zbude 297). Sloupce (číslováno od 0):

 0 age        věk (roky)
 1 sex        1 = muž, 0 = žena
 2 cp         typ bolesti na hrudi (1–4)
 3 trestbps   klidový krevní tlak (mm Hg)
 4 chol       cholesterol v séru (mg/dl)
 5 fbs        glukóza nalačno > 120 mg/dl (1/0)
 6 restecg    klidové EKG (0–2)
 7 thalach    maximální dosažená tepová frekvence
 8 exang      angina při zátěži (1/0)
 9 oldpeak    deprese ST úseku při zátěži
10 slope      sklon ST úseku (1–3)
11 ca         počet velkých cév obarvených při skiaskopii (0–3)
12 thal       výsledek thaliového testu (3, 6, 7)
13 num        diagnóza: 0 = bez nemoci, 1–4 = ischemická choroba srdeční

Zdroj a licence
---------------
screening_seed0.csv: SIMULOVANÁ data vytvořená pro kurz Optimalizace
(VUT FEKT). Hodnoty markerů řádově odpovídají referenčním mezím, nejde ale
o kalibrovaný model populace; rozdíly mezi oblastmi jsou pro názornost
zesílené. Licence CC0 (volné použití).

processed.cleveland.data: UCI Machine Learning Repository, Heart Disease
dataset, Cleveland Clinic Foundation.
Autoři: Janosi A., Steinbrunn W., Pfisterer M., Detrano R. (1988).
https://archive.ics.uci.edu/dataset/45/heart+disease  (DOI 10.24432/C52P4X)
Licence: CC BY 4.0 – při použití uveďte zdroj.
