"""Generátor syntetických fluorescenčních snímků jader buněk (simulační úloha S03).

Každý snímek 256 x 256 px vzniká ze seedu:
- 30–45 eliptických jader (poloosy 7–13 px, náhodné natočení), část z nich
  se dotýká a tvoří shluky po 2–4 jádrech (jako jádra po dělení nebo
  v husté kultuře),
- nerovnoměrný jas jader (různé množství DNA, barvení),
- drobné jasné nečistoty (debris), které jádra nejsou,
- nerovnoměrné osvětlení (lineární gradient + vinětace),
- rozmazání optikou (Gaussova PSF) a Poissonův šum fotonů.

Výstup: `data/snimky-<sada>.npz` s poli
  `snimky`  (n, 256, 256) uint16 – naměřené počty fotonů,
  `pravda`  (n, 256, 256) int32  – pravé značky jader (0 = pozadí, 1..K),
  `seedy`   (n,)                  – seed každého snímku.

Použití (výstup data/snimky-<sada>.npz vedle skriptu, načte ho
``simulator.nacti("<sada>")``):
  python generuj_data.py --seed 5000 --pocet 20 --sada moje
  python generuj_data.py --seed 6000 --sada husta --hustota 1.4   # hustší kultura
  python generuj_data.py --seed 7000 --sada slaba --foton 15      # slabší signál
  python generuj_data.py --oficialni     # znovu oficiální trénovací (8) + test (20)

Oficiální sady (``trenink``, ``test``) skript přepíše jen s ``--oficialni``.
``--hustota`` násobí počet jader (výchozí 1, tedy 30–45 jader), ``--foton``
je počet fotonů na jednotku jasu (výchozí 40; menší = slabší signál
a silnější šum).
"""
import argparse
from pathlib import Path

import numpy as np
from scipy import ndimage as ndi

N = 256


def generuj_snimek(seed, hustota=1.0, podil_shluku=0.45, foton=40.0):
    """Vrátí (snimek uint16, pravda int32) pro daný seed."""
    rng = np.random.default_rng(seed)
    yy, xx = np.mgrid[0:N, 0:N].astype(float)
    pravda = np.zeros((N, N), np.int32)
    vzdal = np.full((N, N), np.inf)          # normovaná "vzdálenost" k nejbližšímu jádru
    jas_obr = np.zeros((N, N))
    jadra = []                               # (cy, cx, a, b)
    cil = int(rng.integers(30, 46) * hustota)
    pokusy = 0
    while len(jadra) < cil and pokusy < 5000:
        pokusy += 1
        a = rng.uniform(8, 13)
        b = a * rng.uniform(0.65, 0.95)
        uhel = rng.uniform(0, np.pi)
        if jadra and rng.random() < podil_shluku:
            # přilepit k existujícímu jádru: střed ve vzdálenosti ~ součet poloměrů
            cy0, cx0, a0, b0 = jadra[rng.integers(len(jadra))]
            smer = rng.uniform(0, 2 * np.pi)
            d = (0.5 * (a0 + b0) + 0.5 * (a + b)) * rng.uniform(0.80, 0.94)
            cy, cx = cy0 + d * np.sin(smer), cx0 + d * np.cos(smer)
            tolerance = 0.70   # smí se dotýkat
        else:
            cy, cx = rng.uniform(14, N - 14, size=2)
            tolerance = 1.15   # samostatné jádro, s odstupem
        if not (12 < cy < N - 12 and 12 < cx < N - 12):
            continue
        # kontrola překryvu: střed nesmí být blíž než tolerance * součet poloměrů
        ok = True
        for (py, px, pa, pb) in jadra:
            dmin = tolerance * (0.5 * (a + b) + 0.5 * (pa + pb))
            if np.hypot(cy - py, cx - px) < dmin:
                if not (tolerance < 1 and (py, px) == (cy0, cx0)):
                    ok = False
                    break
        if not ok:
            continue
        c, s = np.cos(uhel), np.sin(uhel)
        u = ((xx - cx) * c + (yy - cy) * s) / a
        v = (-(xx - cx) * s + (yy - cy) * c) / b
        r = np.sqrt(u ** 2 + v ** 2)
        uvnitr = (r < 1) & (r < vzdal)        # překryv: pixel patří "bližšímu" jádru
        k = len(jadra) + 1
        pravda[uvnitr] = k
        vzdal = np.minimum(vzdal, r)
        jas = rng.uniform(0.45, 1.3)
        # jemná textura chromatinu
        textura = 1 + 0.15 * ndi.gaussian_filter(rng.standard_normal((N, N)), 2) * 6
        prof = np.clip(1 - r ** 6, 0, 1)      # skoro plochý profil s měkkým okrajem
        jas_obr = np.maximum(jas_obr, jas * prof * textura)
        jadra.append((cy, cx, a, b))
    # nečistoty: malé jasné tečky
    for _ in range(rng.integers(8, 16)):
        cy, cx = rng.uniform(5, N - 5, size=2)
        rr = rng.uniform(1.5, 3.2)
        jas_obr = np.maximum(jas_obr, rng.uniform(0.6, 1.4) *
                             (np.hypot(yy - cy, xx - cx) < rr))
    # osvětlení: gradient + vinětace
    smer = rng.uniform(0, 2 * np.pi)
    grad = ((xx - N / 2) * np.cos(smer) + (yy - N / 2) * np.sin(smer)) / N
    vinet = 1 - 0.35 * (((xx - N / 2) ** 2 + (yy - N / 2) ** 2) / (N / 2) ** 2)
    osvetleni = (1 + 0.6 * grad) * vinet
    pozadi = 0.18 + 0.06 * ndi.gaussian_filter(rng.standard_normal((N, N)), 20) * 20
    signal = osvetleni * (pozadi + jas_obr)
    signal = ndi.gaussian_filter(signal, 1.5)             # PSF optiky
    snimek = rng.poisson(np.clip(signal, 0, None) * foton)
    # přečíslovat značky 1..K podle výskytu (jádra úplně zakrytá vypadnou)
    _, inv = np.unique(pravda, return_inverse=True)
    pravda = inv.reshape(N, N).astype(np.int32)
    return snimek.astype(np.uint16), pravda


SADY = {"trenink": (100, 8), "test": (200, 20)}


def uloz(sada, seed0, pocet, slozka, hustota=1.0, foton=40.0):
    seedy = np.arange(seed0, seed0 + pocet)
    dvojice = [generuj_snimek(int(s), hustota=hustota, foton=foton) for s in seedy]
    np.savez_compressed(slozka / f"snimky-{sada}.npz",
                        snimky=np.stack([d[0] for d in dvojice]),
                        pravda=np.stack([d[1] for d in dvojice]),
                        seedy=seedy)
    pocty = [int(d[1].max()) for d in dvojice]
    print(f"{sada}: {pocet} snímků, jader {min(pocty)}–{max(pocty)}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int)
    ap.add_argument("--pocet", type=int, default=20)
    ap.add_argument("--sada", default="moje")
    ap.add_argument("--hustota", type=float, default=1.0, help="násobek počtu jader (výchozí 1)")
    ap.add_argument("--foton", type=float, default=40.0, help="fotony na jednotku jasu (výchozí 40)")
    ap.add_argument("--slozka", default=str(Path(__file__).parent / "data"))
    ap.add_argument("--oficialni", action="store_true",
                    help="přegenerovat oficiální sady trenink a test (jinak se nepřepisují)")
    arg = ap.parse_args()
    slozka = Path(arg.slozka)
    slozka.mkdir(exist_ok=True)
    if arg.oficialni:
        for sada, (s0, n) in SADY.items():
            uloz(sada, s0, n, slozka)
    elif arg.seed is None:
        ap.error("zadejte --seed (vlastní sada), nebo --oficialni (přepíše trenink a test)")
    elif arg.sada in SADY:
        ap.error(f"sada {arg.sada!r} je oficiální; zvolte jiné jméno (--sada moje)")
    else:
        uloz(arg.sada, arg.seed, arg.pocet, slozka, arg.hustota, arg.foton)
