M04 – Segmentace jader: data pro studenty
=========================================

Všechny instance jsou soubory NumPy .npz; načtete je
    z = np.load("instance/sim_0.npz")
    obraz = z["obraz"]; mu0 = float(z["mu0"]); ...
Podrobný popis a konvence (pořadí pixelů, sousedé) jsou v zadání,
oddíl „Data“.

Soubory
-------
instance/sim_0.npz … sim_4.npz
    5 simulovaných snímků 48 x 48 px.
    Jedno velké jádro uprostřed a dvě malá slabě barvená tělíska.
instance/bbbc_A02.npz, bbbc_E05.npz, bbbc_I01.npz, bbbc_L21.npz
    4 ořezy 48 x 48 px ze skutečných snímků BBBC039 s přidaným šumem.
mini_4x4.npz
    Malá instance 4 x 4 px na kontrolu úplným výčtem všech 2^16 masek.
    Klíče obraz, mu0, mu1 a navíc lam (= 0,05, váha délky hranice).
navic/sim_s025_1001.npz … sim_s025_1010.npz
    10 dalších simulovaných snímků stejného druhu jako sim_* (šum 0,25),
    na experimenty a ověření, že závěry platí i mimo pět hlavních
    simulovaných snímků.
navic/sim_sSSS_NNNN.npz pro SSS = 010, 015, 020, 030, 035, 040
                         a NNNN = 1001, 1002, 1003
    Šumová řada: snímky 1001–1003 se šumem o směrodatné odchylce
    SSS/100 (0,10 až 0,40; s025 je výchozí 0,25). Jádro, osvětlení
    i vzorek šumu jsou v řadě stejné, mění se jen síla šumu.
    Soubory v navic/ jsou jen na experimenty; povinné výstupy se týkají
    9 instancí v instance/.
teorie-M04.svg
    Obrázek k teorii v zadání.

Klíče v instance/*.npz a navic/*.npz
----------------------
obraz   float64, tvar (48, 48)  jas pixelů po normalizaci (pozadí ~0,05,
                                jádra ~0,3–0,5); kvůli šumu jsou i hodnoty
                                pod 0 a nad 1 – to je v pořádku, neořezávejte
mu0     float                   typický jas pozadí
mu1     float                   typický jas jádra
plocha  int                     plocha popředí A = počet pixelů jader
                                (= součet masky pravda)
fg      int64, 1D pole          čmáranice „jádro“: indexy pixelů (viz níže)
bg      int64, 1D pole          čmáranice „pozadí“: indexy pixelů
pravda  bool, tvar (48, 48)     ručně anotovaná (BBBC039) nebo simulovaná
                                maska jader; JEN NA VYHODNOCENÍ (IoU),
                                do modelu nepatří (kromě plochy A)

Index pixelu: pixel v řádku r a sloupci c (od 0, řádek 0 nahoře) má index
i = 48·r + c, tedy stejné pořadí jako obraz.ravel() v NumPy.

Zdroj a licence
---------------
Skutečné snímky: BBBC039v1, Broad Bioimage Benchmark Collection,
https://bbbc.broadinstitute.org/BBBC039 – jádra buněk U2OS barvená
Hoechst, ručně anotované masky. Licence CC0 1.0.
Citace: Caicedo J. C. et al., Evaluation of Deep Learning Strategies for
Nucleus Segmentation in Fluorescence Images, Cytometry A 95:952–965, 2019;
Ljosa V., Sokolnicki K. L., Carpenter A. E., Annotated high-throughput
microscopy image sets for validation, Nature Methods 9:637, 2012.
Úprava: jas normalizován percentily 1 a 99,9 do [0, 1], ořez 48 x 48 px
(řádek, sloupec levého horního rohu):
    bbbc_A02  IXMtest_A02_s1  (16, 160)
    bbbc_E05  IXMtest_E05_s2  (184, 352)
    bbbc_I01  IXMtest_I01_s4  (0, 320)
    bbbc_L21  IXMtest_L21_s5  (432, 512)
přidán gaussovský šum se směrodatnou odchylkou 0,25 (simulace krátké
expozice). mu0, mu1 = průměrný jas pozadí a jader v ořezu PŘED přidáním
šumu. Maska pravda = maska popředí z BBBC039 (všechna jádra v ořezu).

Simulované snímky (instance/sim_*, navic/*) a mini instance: vytvořeno
pro kurz Optimalizace (VUT FEKT), volně k použití, úpravám i šíření (CC0).
Parametry simulace podle BBBC039 (pozadí 0,05, jádro 0,45, textura chromatinu ±20 %,
rozmazání optikou, nerovnoměrné osvětlení ±15 %, šum 0,25, v šumové řadě 0,10–0,40).
