Data k úloze M02 – Spolehlivý tep z PPG
=========================================

Každý soubor *.json je jedna instance úlohy (UTF-8, JSON objekt).
Podrobný popis klíčů je v zadání, oddíl „Data“. Stručně:

  tau          časy kandidátů (lokálních maxim PPG) v s od začátku úseku, rostoucí
  a            skóre kandidátů (relativní výška špičky, 0–2), stejná délka jako tau
  pravda_tau   časy skutečných úderů odvozené z EKG (s); jen k vyhodnocení
  signal       PPG vzorkovaná fs_hz = 125 Hz (bez jednotek), jen ke kreslení
  artefakty_s  intervaly [od, do] (s) s přimíchaným pohybovým artefaktem
  nazev, popis, zdroj, zaznam, zacatek_s, delka_s   popis instance

Instance
  bidmc02_artefakty.json     skutečná PPG, BIDMC záznam 02, 0–120 s, + artefakty
  bidmc01_artefakty.json     skutečná PPG, BIDMC záznam 01, 0–120 s, + artefakty
  synt7.json                 syntetická PPG s výraznou dikrotickou vlnou + artefakty
  cista_02.json              skutečná PPG, BIDMC 02, 120–240 s, bez artefaktů
  cista_03.json              skutečná PPG, BIDMC 03, 0–120 s, bez artefaktů
                             (pacient s extrasystolami)
  synt7_kratka_dikrota.json  jako synt7, jen dikrotická vlna přijde dřív
                             (0,24–0,28 s za vrcholem místo 0,30–0,34 s)
  mini.json                  15 kandidátů vyříznutých z bidmc02_artefakty
                             (bez signálu), pro kontrolu úplným výčtem

Obrázek ze zadání: teorie-M02.svg.

Zdroj a licence
  Skutečná PPG a EKG pocházejí z datasetu BIDMC PPG and Respiration Dataset
  v1.0.0 (PhysioNet), https://physionet.org/content/bidmc/1.0.0/
  Autoři: M. A. F. Pimentel, A. E. W. Johnson, P. H. Charlton, D. A. Clifton
  (odvozeno z MIMIC II, Beth Israel Deaconess Medical Centre).
  Citace: Pimentel M. A. F. et al. Towards a Robust Estimation of Respiratory
  Rate from Pulse Oximeters. IEEE Trans. Biomed. Eng. 64(8):1914–1923, 2017.
  Goldberger A. L. et al. PhysioBank, PhysioToolkit, and PhysioNet.
  Circulation 101(23):e215–e220, 2000.
  Licence: Open Data Commons Attribution License v1.0 (ODC-By),
  https://opendatacommons.org/licenses/by/1-0/

  Úpravy vyučujícího: vybrané úseky, filtrace, detekce kandidátů, časy úderů
  z R-kmitů EKG (posunuté na systolický vrchol PPG), uměle přimíchané
  pohybové artefakty (BIDMC je prstová PPG ležících pacientů, artefakty
  v ní ve skutečnosti takto časté nejsou). Syntetická PPG je celá
  simulovaná vyučujícím. Odvozená data smíte v projektu volně používat
  s uvedením zdroje výše.
