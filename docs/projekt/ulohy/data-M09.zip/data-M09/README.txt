Data k úloze M09 – Šum, nebo supresor? Řídký diagnostický model se znaménky
==========================================================================

Formát všech souborů je podrobně popsaný v zadání, oddíl „Data“.
CSV soubory: UTF-8, oddělovač čárka, desetinná tečka, první řádek je hlavička.

Simulovaná data jsou ze dvou nemocnic: soubory s příponou _s45 (nemocnice 1)
a _s112 (nemocnice 2). Formát je pro obě stejný, liší se pacienti, vztahy
mezi markery a skóre a ceny.

trenink_s45.csv, test_s45.csv  (a trenink_s112.csv, test_s112.csv)
    Simulovaní pacienti: 200 trénovacích a 500 testovacích. Sloupce 1–30 jsou
    laboratorní markery ve stejném pořadí jako seznam "markery"
    v markery_s45.json (resp. markery_s112.json), vyjádřené jako z-skóre vůči celé populaci pacientů
    (bez jednotek, průměr v populaci 0, směrodatná odchylka 1). Poslední
    sloupec "skore" je skóre závažnosti (spojité, vyšší = horší, průměr
    kolem 40, není omezené zdola ani shora).

markery_s45.json  (a markery_s112.json)
    Popis markerů: "markery" (názvy), "blok" (orgánový systém: lipidy,
    zanet, ledviny, glykemie, jatra_srdce), "smer" (klinický směr: +1
    marker riziko zvyšuje, -1 snižuje, 0 směr není jistý), "cena_kc"
    (orientační cena vyšetření v Kč), "seed" a "poznamka".

pravda-az-po-odhadu/pravda_s45.json, pravda-az-po-odhadu/pravda_s112.json
    Populační pravda ze simulátoru. NEOTVÍREJTE, dokud si nezapíšete vlastní odhad,
    jinak si zkazíte hlavní pokus úlohy. Klíče: "aktivni_bloky" (bloky, které
    skóre skutečně ovlivňují), "supresory" (markery, které simulátor
    záměrně postavil jako supresory), "sigma" (směrodatná odchylka šumu
    skóre), "blp_vahy" (váhy nejlepšího lineárního prediktoru na celé
    populaci, tj. na nekonečně mnoha pacientech), "blp_proti_smeru"
    (markery, u nichž je populační váha proti klinickému směru).

    Zdroj simulovaných dat: simulátor připravený vyučujícím (latentní
    model se stavem nemoci a rušivým faktorem v každém orgánovém bloku).
    Ceny jsou orientační, odpovídají řádu cen laboratorních vyšetření v ČR,
    nejde o skutečný sazebník. Licence: volně k použití v projektu.

diabetes_efron2004.csv
    Skutečná data: 442 pacientů s diabetem. Sloupce
        vek       věk [roky]
        pohlavi   pohlaví, kódováno 1/2 (zdroj neuvádí, které je které)
        BMI       index tělesné hmotnosti [kg/m2]
        tlak      průměrný arteriální tlak [mm Hg]
        TC        celkový cholesterol v séru
        LDL       LDL cholesterol
        HDL       HDL cholesterol
        TC_HDL    poměr celkový cholesterol / HDL
        log_TG    přirozený logaritmus triglyceridů v séru
        glukoza   glykémie
        progrese  kvantitativní míra progrese nemoci rok po vstupním vyšetření
    Zdroj jednotky laboratorních hodnot neuvádí; podle rozsahu jde
    o mg/dl.
    Původ: Efron B., Hastie T., Johnstone I., Tibshirani R. (2004),
    Least Angle Regression, Annals of Statistics 32(2):407–499.
    Stránka dat: https://www4.stat.ncsu.edu/~boos/var.select/diabetes.html
    Soubor vznikl exportem sklearn.datasets.load_diabetes(scaled=False)
    (scikit-learn 1.9.0, balík pod licencí BSD-3-Clause; data distribuuje
    i R balík lars pod GPL-2).
    Licence: původní zdroj výslovnou licenci neuvádí, požaduje jen citaci.
    Data se všeobecně používají ve výuce; při použití citujte článek výše.

teorie-lasso.svg
    Obrázek k teorii ze zadání (vygenerovaný skriptem vyučujícího).
