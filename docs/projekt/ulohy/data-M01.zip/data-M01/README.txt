Data k úloze M01 – Kdy se člověk lekl? Rozklad kožní vodivosti
==============================================================

Podrobný popis formátu je v zadání, oddíl „Data“. Stručně:

simulace/sim_0.csv … sim_4.csv, simulace/sim_0.json … sim_4.json
    Základní simulace (šum 0,01 µS, uvedené tau jsou správné).
simulace/tezke_5.csv … tezke_7.csv, simulace/tezke_5.json … tezke_7.json
    Těžká varianta (šum 0,02–0,035 µS, uvedené tau s chybou až ±20 %).

    CSV (oddělovač čárka, desetinná tečka, 1 440 řádků = 6 min při 4 Hz):
        t_s                čas vzorku v sekundách (0; 0,25; …; 359,75)
        y_uS               měřená kožní vodivost v µS  -> TOTO je vstup modelu
        tonika_pravda_uS   pravá tonická hladina (jen pro vyhodnocení)
        fazicka_pravda_uS  pravá fázická složka (součet reakcí, jen pro vyhodnocení)
    JSON:
        fs_Hz, n, tau_r_s, tau_d_s   vzorkovací frekvence, počet vzorků a UVEDENÉ
                                     časové konstanty odezvy (ty smí model použít)
        pravda.*                     šum sigma, pravé tau, časy a amplitudy reakcí,
                                     časy podnětů – jen pro vyhodnocení a ověření
        seed, varianta               informace o vzniku instance

    Zdroj: simulace připravená vyučujícím (Batemanova odezva, parametry podle
    literatury: Greco et al., cvxEDA, IEEE TBME 63(4), 2016; Benedek & Kaernbach,
    Ledalab, J. Neurosci. Methods 190, 2010; Boucsein, Electrodermal Activity, 2012).
    Licence: volně k použití v projektu.

realna/Subject1_EDA.csv … Subject5_EDA.csv
    Skutečná kožní vodivost ze zápěstí, celý záznam (~38 min, 8 Hz).
        t_s       čas v sekundách od začátku záznamu
        eda_rel   kožní vodivost v RELATIVNÍCH jednotkách (v originále „NU“,
                  nejde o µS – výsledky uvádějte v rel. j.); hodnoty jsou
                  kvantované (krok ~0,001), u Subject5 je kolem 626–630 s
                  krátký výpadek signálu téměř na nulu
realna/Subject1_faze.csv … Subject5_faze.csv
        t_s, faze   začátky fází protokolu: Relax, PhysicalStress,
                    EmotionalStress, CognitiveStress (fáze trvá do další značky)

    Zdroj: Non-EEG Dataset for Assessment of Neurological Status, PhysioNet
    (noneeg v1.0.0), https://physionet.org/content/noneeg/1.0.0/
    Autoři: Birjandtalab J., Cogan D., Pouyan M. B., Nourani M.: A Non-EEG
    Biosignals Dataset for Assessment and Visualization of Neurological Status,
    IEEE SiPS 2016. Goldberger A. L. et al.: PhysioBank, PhysioToolkit, and
    PhysioNet, Circulation 101(23), 2000.
    Licence: Open Data Commons Attribution License v1.0 (ODC-By) – při použití
    uveďte zdroj. Převedeno z formátu WFDB do CSV beze změny hodnot
    (jen signál EDA a anotace fází).

eda_schema.svg
    Obrázek z teorie v zadání (vygenerovaný ze simulace sim_0).
