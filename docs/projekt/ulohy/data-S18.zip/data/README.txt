Data k simulační úloze S18 (šifrovaný deník lékárníka)

instance.json    šifrované texty (klíč "instance": id, typ, delka, sifra)
pravda-useky.json  JEN PRO VYHODNOCENÍ: k úsekům deníku S… (S40_xx až
                 S1000_xx) správný klíč, otevřený text a odkud úryvek
                 pochází; při hledání ho nepoužívejte. Recepty R… a listy
                 P… pravdu nemají (to je úkol), úspěch tam posoudíte podle
                 čitelnosti textu a vyučující ho ověří.
tetragramy.npy   log10 P všech 26^4 tetragramů, spočtené z korpusu níže
korpus/          čtyři díla, ze kterých je tabulka spočtená

Texty a licence
---------------
Díla jsou volná (autoři zemřeli před více než 70 lety, na Wikizdrojích
s licencí „PD old 70“). Soubory v korpus/ jsou e-knihy exportované
z Wikizdrojů (https://cs.wikisource.org, nástroj ws-export, 5. 11. 2026)
beze změny; přepis a úprava e-knihy jsou dílem dobrovolníků Wikizdrojů
a šíří se pod licencí Creative Commons Uveďte původ – Zachovejte licenci
3.0 Unported (CC BY-SA 3.0, https://creativecommons.org/licenses/by-sa/3.0/)
nebo GNU FDL. Seznam přispěvatelů je na konci každého souboru (oddíl
„O e-knize“), údaje o vydání na jeho začátku.

  Babička               Božena Němcová   https://cs.wikisource.org/wiki/Babička
  Povídky malostranské  Jan Neruda       https://cs.wikisource.org/wiki/Povídky_malostranské
  Krakatit              Karel Čapek      https://cs.wikisource.org/wiki/Krakatit
  Válka s mloky         Karel Čapek      https://cs.wikisource.org/wiki/Válka_s_mloky

Šifrované úseky S… a P… jsou z díla Filosofská historie (Alois Jirásek,
Wikizdroje, https://cs.wikisource.org/wiki/Filosofská_historie, stejná
licence), převedené na velká písmena A–Z a zašifrované; recepty R01–R10
jsou napsané pro tuto úlohu (volné užití). Tabulka tetragramů a šifrované
texty jsou upravené odvozené dílo a šíří se pod CC BY-SA 3.0.
