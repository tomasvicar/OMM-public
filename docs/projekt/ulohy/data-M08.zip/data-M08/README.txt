Data k úloze M08 – Proč bakterie plýtvá cukrem
==============================================

sit.csv
    Výuková metabolická síť (11 reakcí). Formát je podrobně popsaný
    v zadání, oddíl „Data“. Stručně: tři řádky hlavičky začínající
    znakem # (P = rozpočet proteomu, O2 = výchozí strop příjmu kyslíku,
    G_grid = mřížka přísunu glukózy), pak CSV (UTF-8, oddělovač čárka,
    pole s čárkou jsou v uvozovkách) se sloupci
        id, nazev, rovnice, lb, ub, w.
    Jednotky: toky v mmol/gDW/h, růst (tok BIO) v 1/h; proteinové ceny w
    a rozpočet P jsou ilustrační bezrozměrná čísla.
    Zdroj: simulovaná výuková síť připravená vyučujícím; parametry
    (výnosy ATP, poměr proteinových nákladů dýchání a fermentace) podle
    Basan M. et al. (2015), Overflow metabolism in Escherichia coli
    results from efficient proteome allocation, Nature 528:99–104.
    Licence: volně k použití v projektu.

e_coli_core.json
    Skutečná jádrová metabolická síť E. coli (95 reakcí, 72 metabolitů)
    z databáze BiGG Models, formát JSON (COBRA). Jen pro volitelný
    vlastní experiment. Struktura souboru je popsaná v zadání.
    Zdroj: http://bigg.ucsd.edu/static/models/e_coli_core.json
    (staženo 3. 11. 2026).
    Autoři modelu: Orth J. D., Fleming R. M. T., Palsson B. Ø. (2010),
    Reconstruction and Use of Microbial Metabolic Networks: the Core
    Escherichia coli Metabolic Model as an Educational Guide, EcoSal Plus.
    Databáze: King Z. A. et al. (2016), BiGG Models: A platform for
    integrating, standardizing and sharing genome-scale models,
    Nucleic Acids Research 44:D515–D522.
    Licence: podmínky BiGG Models (University of California) – bezplatné
    použití, kopírování, úpravy a šíření pro vzdělávací, výzkumné
    a neziskové účely; komerční použití vyloučeno. Při použití citujte
    obě práce výše.

sit-M08.svg
    Obrázek výukové sítě ze zadání (vygenerovaný skriptem vyučujícího).
