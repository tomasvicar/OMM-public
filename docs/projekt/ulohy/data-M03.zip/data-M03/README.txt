Data k projektové úloze M03 – Zaostřete snímek jader
=====================================================

instance_0.npz
    Měření a pravda pro hlavní instanci (načtení: d = numpy.load("instance_0.npz")).
    Klíče:
      y      pole 64 x 64 (float)  naměřený obraz kamery v počtech fotonů na pixel,
                                   včetně pozadí; y[i, j] je řádek i, sloupec j
      bg     skalár (20.0)         pozadí b ve fotonech na pixel, stejné ve všech
                                   pixelech a přesně známé
      sigma  skalár (2.5)          šířka gaussovské PSF (směrodatná odchylka) v pixelech
      truth  pole 48 x 48 (float)  ostrý obraz (pravda) ve fotonech na pixel – jen pro
                                   vyhodnocení, model ho nesmí použít
      cells  pole 48 x 48 (int32)  maska jader pro vyhodnocení: 0 = pozadí,
                                   1 … 19 = číslo jádra (dotýkající se jádra mají
                                   společné číslo, maska je o pixel širší než jádro)
    Rekonstruovaná oblast 48 x 48 leží uprostřed zorného pole kamery:
    pixel x[p, q] odpovídá pixelu y[p + 8, q + 8] (8 = ceil(3 * sigma)).

human_mitosis.tif
    Původní snímek 512 x 512 (8 bitů) jader lidských buněk obarvených na DNA,
    část buněk je v mitóze. Slouží k vlastním experimentům (jiný výřez, jiná PSF).
    Hlavní instance vznikla takto:
      1. zmenšení 2x průměrem bloků 2 x 2 (256 x 256),
      2. odečtení difuzního pozadí 12 a oříznutí záporných hodnot na 0,
      3. výřez řádky 128–175, sloupce 144–191 (48 x 48),
      4. vynásobení 2 (převod úrovní šedi na fotony) -> truth,
      5. plná konvoluce s gaussovskou PSF (sigma = 2,5 px) -> 64 x 64,
      6. přičtení pozadí 20 fotonů/px a Poissonův šum -> y.

    Zdroj: datový repozitář scikit-image,
      https://gitlab.com/scikit-image/data/-/raw/master/AS_09125_050116030001_D03f00d0.tif
      (v knihovně jako skimage.data.human_mitosis()).
    Autor: David Root (Broad Institute); snímek z přípravy článku
      Moffat J. et al. (2006), A lentiviral RNAi library for human and mouse genes
      applied to an arrayed viral high-content screen, Cell 124(6):1283–98,
      doi:10.1016/j.cell.2006.01.040.
    Licence: CC0 (public domain).

teorie-M03.svg
    Obrázek z textu zadání (PSF, rozmazání, zesílení šumu při inverzi).
