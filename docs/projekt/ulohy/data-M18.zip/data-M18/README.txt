Data k úloze M18 – Ladění klavíru: proč nejde mít všechny kvinty čisté
=====================================================================

Formát souborů je podrobně popsaný v zadání, oddíl „Data“.

intervaly.json
    Váhy intervalů pro 5 skladeb J. S. Bacha (Das Wohltemperierte Clavier I).
    Klíče nejvyšší úrovně jsou identifikátory skladeb:
        wtk1-prelude1  Praeludium 1, C dur, BWV 846
        wtk1-fugue1    Fuga 1, C dur, BWV 846
        bwv848a        Praeludium 3, Cis dur, BWV 848
        bwv849a        Praeludium 4, cis moll, BWV 849
        bwv869b        Fuga 24, h moll, BWV 869
    U každé skladby:
        "title"    popis skladby
        "key"      hlavní tónina jako číslo tónu (0 = C, 1 = Cis, ..., 11 = H)
        "n_notes"  počet not v MIDI souboru
        "weights"  slovník se třemi seznamy po 12 číslech:
                   "P5" kvinty, "M3" velké tercie, "m3" malé tercie;
                   prvek i patří intervalu, jehož DOLNÍ tón je i
                   (0 = C, 1 = Cis, 2 = D, 3 = Es, 4 = E, 5 = F, 6 = Fis,
                    7 = G, 8 = As, 9 = A, 10 = B, 11 = H).
                   Hodnota je podíl doby, po kterou daný interval ve skladbě
                   zní (součet všech 36 čísel je 1). Obraty se počítají ke
                   stejnému intervalu (kvarta G–C nahoru je kvinta C–G,
                   malá sexta E–C nahoru je velká tercie C–E), oktávy se
                   neberou v úvahu.
    Váhy vznikly z MIDI souborů ve složce midi/: pro každý časový úsek, kdy
    se nemění znějící noty, se ke každé dvojici současně znějících not
    přičte délka úseku k odpovídajícímu intervalu; nakonec se vše vydělí
    součtem.

midi/*.mid
    Původní MIDI soubory (notový zápis, ne skutečné ladění). Nejsou nutné
    k základnímu řešení; hodí se, pokud chcete váhy spočítat jinak.

midi/*.rdf
    Metadata z Mutopia Project ke každému MIDI souboru (název, sazeč,
    licence).

teorie-ladeni.svg
    Obrázek k teorii v zadání.

Zdroj a licence
---------------
MIDI soubory: Mutopia Project, https://www.mutopiaproject.org/ftp/BachJS/
(staženo 2026-11-03), skladatel J. S. Bach. Licence všech pěti souborů
podle přiložených .rdf: Public Domain. Sazeči: Tobias Erbsland
(wtk1-prelude1), Andreas Scherer (wtk1-fugue1), Davide Castellone
(bwv848a, bwv849a), Itay Perl (bwv869b).
Soubor intervaly.json a obrázek připravil vyučující z těchto MIDI souborů.
