M16 – Forma na den závodu: data pro studenty
============================================

Všechny soubory instance_*.json mají stejnou strukturu (JSON, UTF-8).
Data jsou SIMULOVANÁ: veřejná data s denní zátěží i měřeným výkonem
s otevřenou licencí nejsou k dispozici. Pro úlohu to nevadí, optimalizuje
se plán, ne parametry.

Soubory
-------
instance_0.json
    Hlavní instance. Učebnicové parametry Banisterova modelu
    k1 = 1, k2 = 2, tau1 = 42 dní, tau2 = 7 dní; rekreační běžkyně
    s průměrem 60 TSS/den za posledních 8 týdnů.

dalsi/instance_101.json ... instance_105.json
    Další instance pro srovnání a testy. Parametry jsou losované
    z rozsahů: tau1 30–50 dní, tau2 4–12 dní, k1 = 1, k2 1,5–3,
    průměrná dosavadní zátěž 45–75 TSS/den, W_max 170–240 TSS/den.

odezva-treninku.svg
    Obrázek ze zadání (odezva výkonu na jeden trénink a na blok tréninku).

Klíče v instance_*.json (podrobně v zadání, oddíl Data)
---------------------------------------------------------
k1, k2          váhy kondice a únavy (bezrozměrné)
tau1, tau2      časové konstanty kondice a únavy [dny]
N, tydnu        délka plánu: N = 84 dní = 12 týdnů
W_max           největší zátěž za jeden den [TSS]
historie_zateze zátěž posledních 56 dní před plánem [TSS], první prvek
                je den -56 (pondělí), poslední den -1 (neděle)
objem_posledniho_tydne   součet posledních 7 prvků historie [TSS]
strop_unavy_G   nejvyšší dovolená únava g(t) [jednotky výkonu]
rust_objemu     dovolený týdenní růst objemu (0.1 = +10 %)
rozpocet_B      celkový objem tréninku za 84 dní [TSS]
lehky_den       den v týdnu s lehkým tréninkem (0 = pondělí)
lehky_den_podil podíl W_max, který smí mít lehký den (0.2)
zavod_hlavni    den hlavního závodu (84)
zavod_pripravny den přípravného závodu pro experiment (63)
seed, popis     jen informace o vzniku instance

Zdroj a licence
---------------
Instance vygeneroval vyučující simulátorem; volně k použití v projektu.
Rozsahy parametrů podle:
- Banister E. W. et al. (1975), A systems model of training for athletic
  performance, Aust. J. Sports Med. 7:57–61.
- Clarke D. C., Skiba P. F. (2013), Rationale and resources for teaching
  the mathematical modeling of athletic training and performance,
  Adv. Physiol. Educ. 37:134–152.
- Busso T. (2003), Variable dose-response relationship between exercise
  training and performance, Med. Sci. Sports Exerc. 35:1188–1195.
TSS (training stress score): 100 = hodina na anaerobním prahu.
