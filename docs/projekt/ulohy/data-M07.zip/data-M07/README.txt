Data k úloze M07 – Marker, který měří laboratoř
================================================

Všechny soubory jsou CSV (UTF-8, oddělovač čárka, desetinná tečka,
první řádek je hlavička). Podrobný popis formátu je v zadání, oddíl „Data“.

laborator_A.csv
    Trénovací data z laboratoře A: 60 vzorků (30 nádorů, 30 kontrol).
    Šarže reagencií souvisí s diagnózou: 26 nádorů je v šarži 2 a 4 v šarži 1,
    26 kontrol je v šarži 1 a 4 v šarži 2.
    Sloupce: id (označení vzorku), sarze (1 nebo 2), y (1 = nádor,
    -1 = kontrola), G001 … G200 (exprese genu v log2).

laborator_B.csv
    Ověřovací data z laboratoře B: 100 vzorků, stejné sloupce. V každé
    třídě je polovina vzorků v šarži 1 a polovina v šarži 2.
    Slouží jen k vyhodnocení hotového panelu, ne k učení ani k volbě
    parametrů.

geny.csv
    Sloupce gen (G001 … G200, ve stejném pořadí jako sloupce expresních
    souborů) a cena_kc (cena qPCR sondy pro daný gen v Kč; ilustrační
    čísla v řádu ceníkových cen komerčních sond, 1 500–6 000 Kč).

schema-sarze.svg
    Obrázek ze zadání (rozdělení vzorků do šarží, ilustrace šaržového genu).

Zdroj a licence
    Data jsou simulovaná vyučujícím (žádná převzatá data), volně k použití
    v projektu. Parametry simulace (log2 exprese, slabé markery s posunem
    0,45–0,7 log2, šaržový posun kolem 2 log2 u několika genů, korelace genů
    v drahách) vycházejí z literatury o šaržových efektech:
    Leek J. T. et al. (2010), Nat Rev Genet 11:733–739;
    Johnson W. E. et al. (2007), Biostatistics 8:118–127.
    Simulovaná data se zvolila proto, že u skutečných dat nikdo neví,
    které geny jsou opravdové markery a které nese šarže; simulátor to ví,
    a u obhajoby se dá ověřit, na čem váš panel stojí.
