Syntetické záznamy EKG pro úlohu S02 (simulace, licence se neřeší).

Každý soubor *.npz (numpy.load) obsahuje:
  ekg   float32, 15000 vzorků, napětí v mV (jeden svod)
  fs    vzorkovací frekvence 250 Hz
  r     int32, indexy vzorků skutečných R vln (počítáno od 0) - značky (pravda)
  extrasystola  bool, stejně dlouhé jako r: True = komorová extrasystola
  typ   "klid" nebo "pohyb" (informace o vzniku záznamu)

Sady:
  klid-trenink/   10 záznamů, Holter vleže (málo artefaktů)
  klid-test/      20 záznamů stejného typu, na kontrolu přenosu
  pohyb-trenink/  10 záznamů z nositelného zařízení při pohybu
  pohyb-test/     20 záznamů stejného typu, na kontrolu přenosu

Detektor značky r nevidí, dostává jen ekg a fs. Značky trénovacích sad
patří do účelové funkce (vyhodnot je potřebuje k výpočtu F1), ladit se
na nich smí. Testovací sady (*-test/) i s jejich značkami jsou jen pro
kontrolu hotového nastavení, do ladění nepatří.
