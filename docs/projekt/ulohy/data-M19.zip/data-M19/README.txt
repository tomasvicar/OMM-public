M19 – Festival bez kolizí: data pro studenty
============================================

Všechny soubory jsou JSON (UTF-8) se stejnou strukturou. Data jsou
SIMULOVANÁ – veřejná data o tom, které kapely chtějí fanoušci vidět,
neexistují. Jména kapel jsou vymyšlená.

Soubory
-------
festival.json               hlavní instance: 24 kapel, 3 pódia, 8 bloků, 3000 fanoušků (seed 1)
mini.json                   malá instance: 8 kapel, 2 pódia, 4 bloky, 600 fanoušků
                            – na kontrolu úplným výčtem (bez pravidel produkce stačí
                            105 rozdělení kapel do dvojic; s pravidly záleží i na tom,
                            který blok a které pódium dvojice dostane)
dalsi/festival-s101.json …  další instance stejné velikosti jako hlavní (seedy 101–103)
dalsi/mensina-02.json …     hlavní instance (seed 1) s jiným podílem metalistů.
                            Číslo v názvu je podíl metalistů v procentech
                            (mensina-02 2 %, mensina-08 8 %, mensina-12 12 %;
                            hlavní festival.json 4 %).

Struktura souboru
-----------------
{
  "popis": "...",
  "seed": 1,                      # seed generátoru (jen pro informaci)
  "bloku": 8,                     # počet časových bloků; blok s indexem s = 0 … bloku-1
  "pody": [                       # pódia; pódium k je pody[k] (od 0), seřazená sestupně podle kapacity
    {"jmeno": "Hlavni", "kapacita": 13000},   # kapacita = počet diváků, kteří se vejdou
    ...
  ],
  "headliner_bloky": [6, 7],      # indexy bloků, ve kterých smějí hrát headlineři (poslední dva)
  "skupiny": ["pop", "rock", "elektro", "hiphop", "metal"],   # žánrové skupiny fanoušků
  "kapely": [                     # kapela b je kapely[b] (od 0)
    {"jmeno": "Leto v Brne",
     "zanr": "pop",               # žánr kapely (stejné názvy jako skupiny fanoušků)
     "popularita": 1.222,         # jen informace (z ní data vznikla), k řešení netřeba
     "headliner": false,          # true = hvězda večera, smí jen do headliner_bloky
     "ocekavana_navstevnost": 5300},   # kolik diváků kapela přitáhne (osob)
    ...
  ],
  "fanousci": [                   # fanoušci z předprodeje; fanoušek f je fanousci[f]
    {"skupina": "elektro",        # žánrová skupina fanouška
     "prani": [18]},              # indexy kapel, které chce vidět
    ...
  ]
}

Platí: počet kapel = bloku × počet pódií, v každém bloku tedy hrají všechna
pódia. Kapela se vejde na pódium, když ocekavana_navstevnost <= kapacita.
V mini.json jsou jen 2 pódia a 4 bloky, headlineři jsou jen dva a smějí jen
do bloku 3.

Zdroj a licence
---------------
Data vytvořil simulátor pro kurz Optimalizace (VUT FEKT): popularita kapel
je lognormální, fanoušek chce kapelu s pravděpodobností úměrnou její
popularitě a oblibě jejího žánru v jeho skupině; očekávaná návštěvnost je
počet zájemců z předprodeje přepočtený na 25 000 návštěvníků. Parametry jsou
smyšlené, v řádu odpovídají středně velkému festivalu.
Data smíte volně používat, upravovat a šířit (CC0).
