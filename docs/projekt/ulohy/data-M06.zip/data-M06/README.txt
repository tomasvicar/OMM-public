M06 – Kolik je které izoformy? Data pro studenty
================================================

Všechny soubory jsou JSON (UTF-8) se stejnou strukturou. Data jsou
SIMULOVANÁ (jeden gen, krátká single-end čtení délky 100 bází).

Soubory
-------
gen_seed0.json     hlavní instance: 5 izoforem, N = 20 000 krátkých čtení
gen_seed101.json   další instance: 5 izoforem, jiné délky exonů a podíly
gen_seed102.json   další instance: 6 izoforem (navíc BGD s kazetovým exonem G)
schema-genu.svg    obrázek ze zadání

Struktura souboru
-----------------
{
  "seed": 0,                  # seed simulátoru (jen pro informaci)
  "read_length": 100,         # délka krátkého čtení r v bázích
  "N": 20000,                 # počet krátkých čtení (= součet všech "count")
  "exons": {"E1": 250, ...},  # délka každého exonu v bázích
  "isoforms": {               # izoforma -> exony v pořadí od 5' ke 3' konci
     "AC": ["E1", "A", "E2", "E3", "E4", "C", "E5"], ...},
  "classes": [                # třídy kompatibility a počty čtení v nich
     {"isoforms": ["AF"], "count": 1189},
     {"isoforms": ["AC", "BC"], "count": 1692}, ...],
  "long_reads": {"AC": 33, ...},            # 100 dlouhých čtení: kolik z každé izoformy
  "ratio_AC_AD": {"lo": 2.02, "hi": 9.86,   # 95% interval pro theta_AC / theta_AD
                  "note": "..."}            # spočtený z long_reads
}

Pořadí izoforem je pořadí klíčů v "isoforms" (json.load ho zachová).
Seznam "classes" obsahuje všechny třídy, které u daného genu mohou
vzniknout, i kdyby v nich bylo 0 čtení.

Zdroj a licence
---------------
Data vyrobil simulátor vytvořený pro kurz Optimalizace (VUT FEKT).
Model čtení je stejný jako v nástrojích kallisto a salmon (Bray et al.
2016, Nat. Biotechnol. 34:525; Patro et al. 2017, Nat. Methods 14:417),
zjednodušený na rovnoměrné pokrytí bez zkreslení. Data smíte volně
používat, upravovat a šířit (CC0).
