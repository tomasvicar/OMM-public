M20 – Senátní obvody: data pro studenty
=======================================

Všechny soubory jsou JSON (UTF-8) se stejnou strukturou. Data jsou
SIMULOVANÁ: žádné skutečné území, žádné volební výsledky.

Soubory
-------
kraj-hlavni.json        hlavní kraj: mřížka 9 x 9, k = 5 obvodů (seed 14)
mini.json               mřížka 3 x 3, k = 3, bez krajského města, kandidáty jsou
                        všechny obce – na kontrolu úplným výčtem
dalsi/kraj-sNNN.json    další kraje ze stejného generátoru (seedy 6, 10, 15),
                        k podle souboru – pro vlastní experiment
schema-obvody.svg       obrázek ze zadání

Struktura souboru
-----------------
{
  "popis": "...", "seed": 14,     # jen pro informaci
  "k": 5,                         # počet obvodů
  "km_na_bunku": 5.0,             # strana buňky mřížky v km
  "mapa": {                       # jen pro kreslení map
    "radky": 9, "sloupce": 9,
    "reka": [4, 4, ...],          # v řádku r teče řeka mezi sloupci reka[r]-1 a reka[r]
    "mosty": [2, 5]               # řádky, ve kterých přes řeku vede most
  },
  "bunky": [{"id": "r0c0", "radek": 0, "sloupec": 0, "obyvatele": 1153}, ...],
  "mesto": ["r2c2", "r2c3", "r3c2", "r3c3"],   # buňky krajského města (blok 2 x 2)
  "celek":  { ...varianta... },  # krajské město jako jedna nedělitelná obec "MESTO"
  "deleno": { ...varianta... }   # krajské město jako 4 městské části (obce r2c2, ...)
}

Varianta ("celek" i "deleno"):
{
  "obce": [{"id": "r0c0",          # identifikátor obce
            "x_km": 2.5, "y_km": 2.5,  # poloha středu v km (x doprava, y dolů)
            "obyvatele": 1153,
            "bunky": ["r0c0"]}, ...],   # buňky mapy, které obec tvoří
  "hrany": [["r0c0", "r0c1"], ...],     # sousední obce (neorientovaně, každá dvojice jednou);
                                        # přes řeku vede hrana jen v řádcích s mostem
  "kandidati": ["r0c8", ...]            # obce, které smějí být centrem obvodu
}

Kandidáti jsou 30 nejlidnatějších obcí dané varianty (v mini.json všech 9).
Sada kandidátů je součást zadání: centrum obvodu smí být jen kandidát.

Zdroj a licence
---------------
Vytvořeno syntetickým generátorem pro kurz Optimalizace (VUT FEKT).
Parametry jsou řádově podle ČR: tolerance 15 % podle § 59a odst. 2 zákona
č. 247/1995 Sb. (tam se týká počtu voličů), velikosti obcí řádově podle
tabulek ČSÚ "Počet obyvatel v obcích". Data smíte volně používat,
upravovat a šířit (CC0).
