M15 – Pojištění nemocnice proti špatnému roku: data pro studenty
================================================================

Hračkový model pro výuku optimalizace, ne pojistně-matematická kalkulace
skutečné nemocnice. Všechny peněžní hodnoty jsou v mil. Kč za rok.

Soubory
-------
hlavni.json                 hlavní instance, S = 2000 možných let
dalsi/instance-NNN.json     5 dalších instancí (jiné parametry rizik, vrstvy
                            smluv i přirážky) pro srovnání
hlavni-nove-scenare.json    50 000 NOVÝCH simulovaných let se stejnými riziky;
                            smlouvy a pojistné berte z hlavni.json (klíč "smlouvy"
                            je zde zkopírovaný). Jen pro vlastní experiment.
mini.json                   S = 20 let, alfa = 0,9 (CVaR = průměr 2 nejhorších);
                            na ruční kontrolu a testy. Má vlastní pojistné.
realna/eurostat_elektrina_cz.csv   skutečná cena elektřiny (viz níže)
realna/cnb_kurzy_eur_usd.csv       skutečné denní kurzy EUR/CZK a USD/CZK
realna/historie.csv         35 meziročních log-změn [elektřina, EUR/CZK] po
                            pololetích, ze kterých se losují scénáře
teorie-M15.svg              obrázek ze zadání

Struktura souboru instance (JSON, UTF-8)
----------------------------------------
{
  "popis": "...",
  "S": 2000,                 # počet scénářů (let), s = 0..S-1
  "alfa": 0.95,              # hladina CVaR
  "K": 147,                  # navržený limit ministerstva na CVaR [mil. Kč]
  "slozky": ["energie", "kurz_eur", "epidemie", "pristroje"],
  "ztraty": [[4 čísla], ...],# S řádků: ztráta nad rozpočet po složkách v daném roce
                             # [mil. Kč]; energie a kurz mohou být záporné (úspora)
  "krize": [0/1, ...],       # S čísel: 1 = krizový rok
  "smlouvy": [               # 7 smluv, pořadí j = 0..6 je ve všech souborech stejné
    {"nazev": "...",
     "slozka": "energie" | "kurz_eur" | "epidemie" | "pristroje" | "celkem" | "krize",
     "a": ..., "b": ...,     # vrstva: smlouva kryje ztrátu mezi a a b [mil. Kč]
     "prirazka": ...,        # lambda_j, např. 0.115 = 11,5 %
     "pojistne": ...}        # pi_j [mil. Kč za celou smlouvu, x_j = 1]
  ]
}

Výplata smlouvy j v roce s (celá smlouva, x_j = 1):
    slozka = jedna ze 4 složek:  P = min(max(ztrata_slozky - a, 0), b - a)
    slozka = "celkem":           totéž pro součet všech 4 složek
    slozka = "krize":            P = b, je-li krize[s] = 1, jinak 0
Pojistné: pojistne = (1 + prirazka) * průměr výplat P přes S scénářů instance.

Zdroj a licence
---------------
Skutečná data:
- Eurostat, datová sada nrg_pc_205 (Electricity prices for non-household
  consumers, bi-annual data), řada CZ, spotřeba 2–20 GWh/rok, bez daní,
  Kč/kWh, pololetí 2007-S2 až 2026-S1. Staženo 2026-11-03 z
  https://ec.europa.eu/eurostat/api/dissemination/sdmx/2.1/data/nrg_pc_205
  © European Union, Eurostat; opětovné užití s uvedením zdroje (CC BY 4.0).
- Česká národní banka, kurzy devizového trhu (EUR/CZK, USD/CZK), 2000–2025,
  https://www.cnb.cz/ ; údaje lze přebírat s uvedením zdroje (zdroj: ČNB).
historie.csv: dlog_elektrina = ln(cena v pololetí / cena ve stejném pololetí
loni), dlog_eur = totéž pro průměrný kurz EUR/CZK v pololetí. Pololetí S1 a S2
téhož roku se překrývají, takže 35 řádků odpovídá asi 18 nezávislým rokům.

Simulované složky (krizový rok, epidemie, poruchy přístrojů, rozpočty, vrstvy
a přirážky smluv) vytvořil generátor kurzu Optimalizace (VUT FEKT); parametry
jsou hrubé řádové odhady bez konkrétní citace. Scénář vždy vezme celou dvojici
[elektřina, kurz] ze stejného historického období (zachová se skutečný souběh),
krizový rok losuje období z horní čtvrtiny „stresu“ a zvětší epidemii 4–7×.
Simulovaná data i odvozené soubory smíte volně používat, upravovat a šířit (CC0).
