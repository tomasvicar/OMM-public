M11 – Plán bolusů inzulinové pumpy: data pro studenty
=====================================================

Data jsou SIMULOVANÁ hračkovým lineárním modelem pro výuku optimalizace.
Nejde o klinický model ani o návod k dávkování inzulinu.

Soubory
-------
hlavni.json              hlavní instance (seed 5)
dalsi/instance-NNN.json  10 dalších instancí (seedy 101–110) pro srovnání a experimenty
hlavni-navrat.json       stejný pacient a jídlo jako hlavni.json, ale účinek inzulinu
                         i jídla časem odezní (glykémie se vrací k bazální hodnotě);
                         jen pro vlastní experiment
model-glykemie.svg       obrázek ze zadání

Struktura souboru (JSON, UTF-8)
-------------------------------
{
  "popis": "...",
  "dt_min": 5,               # délka kroku v minutách
  "N_G": 96,                 # počet časů glykémie: k = 0..95, čas t_k = 5*k min (8 h)
  "N_U": 72,                 # počet možných dávek: j = 0..71, dávka v čase 5*j min (6 h)
  "u_max": 4.0,              # největší dávka v jednom kroku [U]
  "U_tot": 6.0,              # strop součtu všech dávek [U]
  "scenare": [0.7, 1.0, 1.3],# násobek ohlášeného jídla ve scénářích s = 0, 1, 2
  "h": [96 čísel],           # odezva glykémie na 1 U podanou v kroku 0 [mg/dl];
                             # h[0] = 0, hodnoty klesají k -ISF
  "G_free": [[96], [96], [96]], # glykémie bez inzulinu pro scénáře s = 0, 1, 2 [mg/dl]
  "pacient": {               # parametry, ze kterých simulátor h a G_free spočítal
    "G0": ...,               # glykémie v čase 0 [mg/dl]
    "ISF": ...,              # pokles glykémie po úplném účinku 1 U [mg/dl/U]
    "CR": ...,               # kolik gramů sacharidů "pokryje" 1 U [g/U]
    "sacharidy_g": ...,      # ohlášené jídlo [g]
    "jidlo_krok": ...,       # krok k, ve kterém pacientka začne jíst (čas 5*k min)
    "inzulin_maximum_min":..,# kdy je inzulin nejaktivnější po podání [min]
    "jidlo_maximum_min": ...,# kdy se sacharidy vstřebávají nejrychleji [min]
    "drift_mg_dl_za_h": ..., # pomalý posun glykémie bez jídla (nepřesný bazál)
    "navrat_tau_min": null   # null = trvalý účinek; číslo = časová konstanta návratu
  }
}

Glykémie ve scénáři s při plánu dávek u (u[j] v U, j = 0..71):
    G_s[k] = G_free[s][k] + sum_{j <= k} h[k - j] * u[j]

Zdroj a licence
---------------
Instance vytvořil generátor kurzu Optimalizace (VUT FEKT). Parametry (ISF 30–50,
CR 10–15, jídlo 30–60 g, maximum účinku inzulinu 60–90 min, vstřebávání 30–50 min,
nejistota odhadu sacharidů ±30 %) leží v mezích uváděných v edukačních
materiálech pro diabetes 1. typu; tvar křivek vychází z myšlenky křivek
"insulin action / carb absorption" open-source systémů OpenAPS/Loop (žádný
jejich kód ani data). Data smíte volně používat, upravovat a šířit (CC0).
