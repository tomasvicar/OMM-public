S12 - záplaty z perikardu: balení dílů do pásu (simulovaná data)

hlavni.json         hlavní instance, 24 dílů (9 cípů, 8 kruhů, 4 elipsy, 3 proužky)
dalsi/s{100..109}   10 dalších instancí se stejným složením, jinými rozměry, vadami a vlákny

Simulátor je načte sám: Pas() je hlavní instance, Pas("dalsi/s100.json") další.
Význam klíčů a pravidla dekodéru: viz zadání a docstring simulator.py.
Tvary, rozměry a pole vláken jsou ilustrační, ne z konkrétní výroby.
