M13 – Výměna ledvin: data pro studenty
=====================================

Všechny soubory jsou JSON (UTF-8) se stejnou strukturou. Data jsou
SIMULOVANÁ – skutečná data z programů párové výměny nejsou veřejná.

Soubory
-------
hlavni.json           hlavní instance: 50 párů, 2 altruisté (pool "nahromadeny", seed 2026)
mala.json             malá instance: 10 párů, 1 altruista (seed 7) – na kontrolu úplným výčtem
dalsi/nahromadeny-50-sNNN.json   12 instancí (s101–s112), 50 párů, 2 altruisté, řidší "nahromaděný" pool
dalsi/saidman-50-sNNN.json       12 instancí (s101–s112), 50 párů, 2 altruisté, hustý pool nově příchozích párů
dalsi/nahromadeny-30-sNNN.json   3 menší instance (30 párů)
dalsi/nahromadeny-80-sNNN.json   3 větší instance (80 párů; seedy 101, 102, 104)

Struktura souboru
-----------------
{
  "seed": 2026,                 # seed generátoru (jen pro informaci)
  "pool": "nahromadeny",        # varianta poolu: "nahromadeny" nebo "saidman"
  "popis": "...",
  "pary": [                     # páry pacient–dárce; pár s indexem i je pary[i] (od 0)
    {"id": "P01",               # jméno pro výpisy, P01 = index 0
     "pacient_abo": "O",        # krevní skupina pacienta (O, A, B, AB)
     "darce_abo": "A",          # krevní skupina dárce z páru
     "pra": "nizke",            # senzibilizace pacienta: "nizke", "stredni", "vysoke"
     "pc": 0.05},               # pravděpodobnost pozitivního crossmatche s náhodným dárcem
    ...
  ],
  "altruiste": [                # dárci bez příjemce; altruista a je altruiste[a] (od 0)
    {"id": "A1", "darce_abo": "O"}, ...
  ],
  "hrany": [[i, j], ...],             # dárce páru i smí darovat pacientovi páru j
  "hrany_altruistu": [[a, j], ...]    # altruista a smí darovat pacientovi páru j
}

Slučitelnost (krevní skupiny i protilátky) je už započtená v hranách,
nic dalšího se z polí "pacient_abo", "pra", "pc" počítat nemusí.
Pole "pra" se hodí pro vlastní experiment (priorita těžko slučitelných).

Zdroj a licence
---------------
Instance vytvořil syntetický generátor podle parametrů z článku
Saidman S. L., Roth A. E., Sönmez T., Ünver M. U., Delmonico F. L.:
Increasing the opportunity of live kidney donation by matching for two- and
three-way exchanges. Transplantation 81(5):773–782, 2006.
Varianta "nahromadeny" mění podíl pacientů s nízkým/středním/vysokým PRA
na 50/20/30 % – výuková stylizace poolu, kde se hromadí těžko slučitelní
pacienti; na žádný registr kalibrovaná není.
Data jsou vytvořená pro kurz Optimalizace (VUT FEKT) a smíte je volně
používat, upravovat a šířit (CC0).
