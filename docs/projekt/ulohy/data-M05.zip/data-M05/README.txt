M05 – Sledování buněk ve videu: data pro studenty
=================================================

Data jsou SIMULOVANÁ (časosběrné video fluorescenčně obarvených jader,
po detekci jader). Formát souborů je podrobně popsaný v zadání, oddíl „Data“.

Soubory
-------
video_seed01.json … video_seed11.json
    11 videí po 10 snímcích, zorné pole 120 × 120 µm, výchozí parametry
    (26 buněk na začátku, dělení 5 % a výpadek detektoru 5 % za snímek).
    Hlavní instance je video_seed01.json.
bez_vypadku/video_seed01.json … video_seed11.json
    stejná videa (stejné seedy) bez výpadků detektoru (p_miss = 0);
    pro srovnání, co způsobují výpadky.
dalsi_seedy/video_seed21.json … video_seed30.json
    10 dalších videí se stejnými výchozími parametry; na vlastní experiment
    (platí závěry i na jiných videích?).
varianty/<varianta>/video_seed21.json … video_seed25.json
    těžší data na vlastní experiment, každá varianta 5 videí (seedy 21–25,
    jinak výchozí parametry):
    husta_n45/    hustší video, 45 buněk na začátku místo 26
    vypadky_10/   častější výpadky detektoru, 10 % místo 5 %
    deleni_10/    častější dělení, 10 % za snímek místo 5 %
    snimku_20/    delší video, 20 snímků místo 10
mini.json
    ručně sestavená mini instance: 3 buňky, 3 snímky, jedno dělení;
    na kontrolu modelu úplným výčtem.
mini_vypadek.json
    stejná scéna, detektor ve snímku 1 přehlédl jádro t01_02.
schema-M05.svg
    obrázek ze zadání.

Struktura JSON (stručně)
------------------------
seed, frames (počet snímků T), field_um (strana zorného pole v µm),
params (parametry, se kterými instance vznikla, jen pro informaci),
detections: seznam {"id", "t", "x", "y"} – t = číslo snímku od 0,
    x, y = poloha středu jádra v µm; id "tTT_NN" je jen jméno,
    číslo NN NENÍ identita buňky (v každém snímku je pořadí náhodné),
truth_links: pravé spoje [id_rodic, id_potomek] – JEN pro hodnocení
    přesnosti, model je nesmí použít,
truth_divisions: id detekcí matek, které se před dalším snímkem
    rozdělily – JEN pro hodnocení.

Zdroj a licence
---------------
Data připravil vyučující kurzu; parametry hrubě podle popisu
datasetu Fluo-N2DL-HeLa z Cell Tracking Challenge (Ulman V. et al.,
Nature Methods 14, 2017; Maška M. et al., Nature Methods 20, 2023).
Hodnoty jsou didaktické, nejde o fit na konkrétní experiment.
Data jsou volně k použití v projektu.
