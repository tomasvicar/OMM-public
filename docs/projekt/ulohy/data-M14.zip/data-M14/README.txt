M14 – Klinické stáže: data pro studenty
======================================

Všechny soubory jsou JSON (UTF-8) se stejnou strukturou. Data jsou
SIMULOVANÁ – skutečné preference z párovacích řízení se nezveřejňují.

Soubory
-------
hlavni.json            hlavní instance: 30 studentů, 8 pracovišť, 33 míst (seed 101)
mala.json              malá instance: 6 studentů, 3 pracoviště, 7 míst (seed 4)
                       – na kontrolu úplným výčtem (3^6 = 729 přiřazení)
dalsi/s100.json … s129.json
                       30 instancí se stejnými parametry jako hlavní
                       (beta = 1.5, gama = 0.7), jiné seedy; hlavní = s101
dalsi/sken/beta{B}-gama{G}-s{N}.json
                       instance 30 x 8 pro B v {0, 0.75, 1.5, 3},
                       G v {0.3, 0.7, 0.95} a seedy N = 100 … 111
blokujici-dvojice.svg  obrázek ze zadání

Struktura souboru
-----------------
{
  "seed": 101,               # seed generátoru (jen informace)
  "beta": 1.5,               # jak moc se studenti shodují v oblibě pracovišť
  "gama": 0.7,               # jak moc se pracoviště shodují v pořadí studentů
  "studenti": ["S01", ...],  # jména; student s indexem s je studenti[s] (od 0)
  "pracoviste": ["Kardiologie FN", ...],  # pracoviště h je pracoviste[h] (od 0)
  "kapacity": [3, 4, ...],   # kapacity[h] = počet míst na pracovišti h
  "pref_studentu": [[1, 4, 3, 0, 5, 7, 6, 2], ...],
        # pref_studentu[s] = indexy VŠECH pracovišť od nejoblíbenějšího
        # po nejméně oblíbené (permutace 0 … H-1)
  "pref_pracovist": [[12, 3, ...], ...]
        # pref_pracovist[h] = indexy VŠECH studentů od nejžádanějšího
        # po nejméně žádaného (permutace 0 … S-1)
}

Pořadí se počítá od 1: pracoviště pref_studentu[s][0] má u studenta s
pořadí 1, pref_studentu[s][1] pořadí 2 atd.

Jak data vznikla
----------------
Studenti: užitek u_sh = beta * a_h + e_sh, kde a_h je společná
"atraktivita" pracoviště (fakultní pracoviště víc, okresní nemocnice
méně) a e_sh je náhodný šum (Gumbelovo rozdělení), seřazeno sestupně
(Plackettův–Luceův model; R. D. Luce 1959, R. L. Plackett 1975).
Pracoviště: skóre = gama * prospech_s + sqrt(1 - gama^2) * pohovor_hs,
prospěch je společný všem pracovištím, pohovor je pro každé pracoviště
jiný; seřazeno sestupně. Volba parametrů je ilustrační, ne kalibrovaná na
skutečná data; názvy pracovišť jsou fiktivní.

Zdroj a licence
---------------
Data jsou vytvořená pro kurz Optimalizace (VUT FEKT) a smíte je volně
používat, upravovat a šířit (CC0).
