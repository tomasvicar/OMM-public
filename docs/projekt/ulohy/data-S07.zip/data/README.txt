Simulovaná data pro úlohu S07 (syntetická, licence se neřeší).

Instance s1 (hlavní) a s2-s4 (stejná nemocnice, jiní pacienti a jiná vyšetření):
  trenink_s<N>.csv        200 pacientů, sloupce V01-V80 (hodnoty vyšetření
                          v různých jednotkách) a nemoc (0 = zdravý, 1 = nemocný)
  vysetreni_s<N>.csv      sloupce vysetreni, cena_kc (cena na pacienta v Kč)
  novi_pacienti_s<N>.csv  2000 nových pacientů, stejné sloupce - JEN PRO
                          ZÁVĚREČNÉ VYHODNOCENÍ, ne pro výběr ani ladění
