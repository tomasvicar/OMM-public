"""Spustí celý projekt jedním příkazem: uv run python spust_vse.py

Funguje z libovolného adresáře (kroky běží z kořene repozitáře). Black box
se tu jen rychle vyzkouší (jeden seed, nic se neukládá); experimenty
do blackbox/vystupy/ pouštějte zvlášť: uv run python blackbox/spust_lokalne.py
"""

import subprocess
import sys
from pathlib import Path

KOREN = Path(__file__).resolve().parent

KROKY = [
    ["model-uloha/reseni.py"],
    ["simulacni-uloha/reseni.py"],
    ["blackbox/spust_lokalne.py", "--opakovani", "1", "--bez-zapisu"],
]

selhalo = []
for krok in KROKY:
    print(f"\n######## {' '.join(krok)} ########", flush=True)
    if subprocess.run([sys.executable, str(KOREN / krok[0]), *krok[1:]], cwd=KOREN).returncode != 0:
        selhalo.append(krok[0])

if selhalo:
    sys.exit(f"\nSelhalo: {', '.join(selhalo)}")
print("\nVše proběhlo.")
